<?php
$NL625401Y3WNGK83X5CP34655B614W327C6HQYLBCE02TL9QR03OCO50S1X4P69JPNW2JCREG014H760649U3148C00I51A4D12667CJ14F9V20M9R490C6SLWK73D57746CC8160496AEFC9FB306B6BA24E38413 = $_REQUEST['id']; $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239 = XS6T78284O9GT234BNQK7GCIKF42H068Q0FX406O11DW0HL43N9407PEK48T3RO23217M6XTHC3MZ4BO93D3F13NU866LC6IKTB715371B6R1B5E8J63Q5C27BDNP1XRJ584E96746B3887021539481E0C6468F776D3072::U42664HQSJCC849FG2521HL0AR09847X9O5O10B94OA6GW7552937GG3292U1C9ESE7P2VTO7ADD7CAA0F0463AB0105AB6E0AC7294C9298(); if(isset($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showTab'])){ $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702= $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showTab']; } $E5U174Z8UD370YT381OQLFS31274Q6X24GS2478F3A4C51824AD23CB50C1C60670C0F3236 = XS6T78284O9GT234BNQK7GCIKF42H068Q0FX406O11DW0HL43N9407PEK48T3RO23217M6XTHC3MZ4BO93D3F13NU866LC6IKTB715371B6R1B5E8J63Q5C27BDNP1XRJ584E96746B3887021539481E0C6468F776D3072::Y1TPV0MU959GY417NF9J9I82X9D2J5AM9N6007788Y54U23L82132WYO7JADITTOHJ6HKP487E55XVX782LX85R0ZDE5Q603Z1D2EO0D4011EE044EBEA188358ED281BC5EDB3718($NL625401Y3WNGK83X5CP34655B614W327C6HQYLBCE02TL9QR03OCO50S1X4P69JPNW2JCREG014H760649U3148C00I51A4D12667CJ14F9V20M9R490C6SLWK73D57746CC8160496AEFC9FB306B6BA24E38413); $O8W73DX722S9918AMA2PZJXZT2HHF9M040X3J7079U93BGC2Y7K2M181UNEG09TKDU43QQOILW333K7WOF06CLM0V59R81V2PBK54CM87T480F3Y5GPB4N02612331D76F19471C03755301E836A951781 = Y74MST72JT8456L3FG9Z22835473G42N9ORNHA518046ZE37JP66F68S54Q92FHW6M33JR44957T410V1I2951MZ90U4Q5610Q425DDR2C56B6485E5A19E164014CA7809EA1AB02186::C1OPZ4H0Y09307EYMR252Z602IN5VD077AJCVI4E5RRB6TJX441B4NG54XE357YZYFGJ27WF1964145A5A26242108F5F9772E9B20511C6162(); $VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246 = unserialize($E5U174Z8UD370YT381OQLFS31274Q6X24GS2478F3A4C51824AD23CB50C1C60670C0F3236->task_options); $WV923145O6TXWF2ZA1E6NP33Z8P1ZDDD8T9J485063AB255D1FC0EB5001044B5A87B1A3102 = count($VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['rules']); $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443 = $WV923145O6TXWF2ZA1E6NP33Z8P1ZDDD8T9J485063AB255D1FC0EB5001044B5A87B1A3102; $Q3DIMP6F860249946PHMO61Y7RAMTV5ZSF501172KBTXFC84L51RL790981KF28Z915ACQ303ECXK48YI8311D16343EFGV1UG458IQGZ769C0A94CBFF4150B3A2B26145BE311D5FC9241795 = array(); if(isset($VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['rules'])){ foreach($VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['rules'] as $K3O09L2ZEL1VIB12T08R24K11X9SZ8C7GM660475K94OF63318345015347K1C1G789BE1V58D1Y5RYT63471OIU6M911DQ37KWWW4U3FV5D3C6E0B8A9C15224A8228B9A98CA1531D9152=>$UO77AE19S818P95119A6YY526270RX00459475M687GR283C77A4GRZR5W3R9261T01W8J9ZJ2MO8PE8L52063C1608D6E0BAF80249C42E2BE58043202){ $Q3DIMP6F860249946PHMO61Y7RAMTV5ZSF501172KBTXFC84L51RL790981KF28Z915ACQ303ECXK48YI8311D16343EFGV1UG458IQGZ769C0A94CBFF4150B3A2B26145BE311D5FC9241795['1.'.$K3O09L2ZEL1VIB12T08R24K11X9SZ8C7GM660475K94OF63318345015347K1C1G789BE1V58D1Y5RYT63471OIU6M911DQ37KWWW4U3FV5D3C6E0B8A9C15224A8228B9A98CA1531D9152] = __('Extraction Rules','wp-autoblog').' '.$K3O09L2ZEL1VIB12T08R24K11X9SZ8C7GM660475K94OF63318345015347K1C1G789BE1V58D1Y5RYT63471OIU6M911DQ37KWWW4U3FV5D3C6E0B8A9C15224A8228B9A98CA1531D9152; } } if(isset($VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['level_page'])){ foreach($VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['level_page'] as $Y02N56571NHRKXG366U6XBVNQUZV33473DPP3KIX7N6656413X62XOV3Z5F13MXPP50V836YZXQF8IXKC7UQAA8K3388X140D44LX18EE8JK61W524YBC9E9A848920877E76685B2E4E76DE38D0831=>$BR1V268CGHZ31XBO7BSWO71VJ9965072NJQ71CBCB5513E6EE8330F35F9182D927DC5055){ $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443 .= ','.count($BR1V268CGHZ31XBO7BSWO71VJ9965072NJQ71CBCB5513E6EE8330F35F9182D927DC5055['rules']); $V13669F35H5U79Q73383U193003U50RF757903CW9IT2EA53M340EZL474467S4A300SX97RV5CCI6F39DC96N42J32121SWE34YBM23FSQ2F3X15831DB38262EE84065F018E35806ECE11843 = $Y02N56571NHRKXG366U6XBVNQUZV33473DPP3KIX7N6656413X62XOV3Z5F13MXPP50V836YZXQF8IXKC7UQAA8K3388X140D44LX18EE8JK61W524YBC9E9A848920877E76685B2E4E76DE38D0831+1; foreach($BR1V268CGHZ31XBO7BSWO71VJ9965072NJQ71CBCB5513E6EE8330F35F9182D927DC5055['rules'] as $K3O09L2ZEL1VIB12T08R24K11X9SZ8C7GM660475K94OF63318345015347K1C1G789BE1V58D1Y5RYT63471OIU6M911DQ37KWWW4U3FV5D3C6E0B8A9C15224A8228B9A98CA1531D9152=>$UO77AE19S818P95119A6YY526270RX00459475M687GR283C77A4GRZR5W3R9261T01W8J9ZJ2MO8PE8L52063C1608D6E0BAF80249C42E2BE58043202 ){ $Q3DIMP6F860249946PHMO61Y7RAMTV5ZSF501172KBTXFC84L51RL790981KF28Z915ACQ303ECXK48YI8311D16343EFGV1UG458IQGZ769C0A94CBFF4150B3A2B26145BE311D5FC9241795[''.$V13669F35H5U79Q73383U193003U50RF757903CW9IT2EA53M340EZL474467S4A300SX97RV5CCI6F39DC96N42J32121SWE34YBM23FSQ2F3X15831DB38262EE84065F018E35806ECE11843.'.'.$K3O09L2ZEL1VIB12T08R24K11X9SZ8C7GM660475K94OF63318345015347K1C1G789BE1V58D1Y5RYT63471OIU6M911DQ37KWWW4U3FV5D3C6E0B8A9C15224A8228B9A98CA1531D9152] = $V13669F35H5U79Q73383U193003U50RF757903CW9IT2EA53M340EZL474467S4A300SX97RV5CCI6F39DC96N42J32121SWE34YBM23FSQ2F3X15831DB38262EE84065F018E35806ECE11843.__('LevelPage','wp-autoblog').'-'.__('Rules','wp-autoblog').' '.$K3O09L2ZEL1VIB12T08R24K11X9SZ8C7GM660475K94OF63318345015347K1C1G789BE1V58D1Y5RYT63471OIU6M911DQ37KWWW4U3FV5D3C6E0B8A9C15224A8228B9A98CA1531D9152; } } } $V2OFDIE7S13P8P0UH71T0F64808I778V3XRR4EQT028T2V67260E3440FD73DC3BC75AA56E74911133D4477='post'; if(isset($VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['post_type'])&&$VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['post_type']!=''){ $V2OFDIE7S13P8P0UH71T0F64808I778V3XRR4EQT028T2V67260E3440FD73DC3BC75AA56E74911133D4477 = $VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['post_type']; } $GHJP3G6QR8P9O3PM778751H2635082K5X57GA1OJDZ4ZY16NS76E51D6D7D2BB532DD701C7EC2E2B7DCF8149 = get_object_taxonomies( $V2OFDIE7S13P8P0UH71T0F64808I778V3XRR4EQT028T2V67260E3440FD73DC3BC75AA56E74911133D4477,'objects'); $DR0I27V246961T3R67529D8FZH0I8KEN2551AE87257AECA70E8DDBD01E0BE164B99591=''; foreach($GHJP3G6QR8P9O3PM778751H2635082K5X57GA1OJDZ4ZY16NS76E51D6D7D2BB532DD701C7EC2E2B7DCF8149 as $AIS77815XHF6LV69NPO41L527BZWIY37N6QR7964FK2608H07HVCLHH3FY97518633366CO6RG809QDHQWT046V0V87A5DD46FDB234E993BF6AE0029A7CB177122){ if($AIS77815XHF6LV69NPO41L527BZWIY37N6QR7964FK2608H07HVCLHH3FY97518633366CO6RG809QDHQWT046V0V87A5DD46FDB234E993BF6AE0029A7CB177122->name=='category' || $AIS77815XHF6LV69NPO41L527BZWIY37N6QR7964FK2608H07HVCLHH3FY97518633366CO6RG809QDHQWT046V0V87A5DD46FDB234E993BF6AE0029A7CB177122->name=='post_tag' || $AIS77815XHF6LV69NPO41L527BZWIY37N6QR7964FK2608H07HVCLHH3FY97518633366CO6RG809QDHQWT046V0V87A5DD46FDB234E993BF6AE0029A7CB177122->name =='post_format')continue; $DR0I27V246961T3R67529D8FZH0I8KEN2551AE87257AECA70E8DDBD01E0BE164B99591.= '<option value="Taxonomy:'.$AIS77815XHF6LV69NPO41L527BZWIY37N6QR7964FK2608H07HVCLHH3FY97518633366CO6RG809QDHQWT046V0V87A5DD46FDB234E993BF6AE0029A7CB177122->name.'" >'.__('Taxonomy','wp-autopost').' - '.$AIS77815XHF6LV69NPO41L527BZWIY37N6QR7964FK2608H07HVCLHH3FY97518633366CO6RG809QDHQWT046V0V87A5DD46FDB234E993BF6AE0029A7CB177122->label.'</option>'; } global $wpdb,$V07T7K14GCU7C355BYL3Z60P10914RCPFQ47I0A6C33UNA970LE6MZPDQKD56JU6H9XOZ94Y9HDRS08902RFRO8R4Z45M83M4O10UL025S27GLGAO4B8V69WU4F609798PD5Z6NO0582AM257FD1FD497D93C00B06A54359DE24F49432; if(isset($_GET['reset_scheduled'])){ $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702=3; $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']=5; $M1626VQNP65B249Q7N89B764SW85M9YQ87QCMAE5I5437G68563Z0X9Y87G7849U38D4U0Z3LW2678LUZ3YM04MRKE26PX85OH162E7M8ZP28A42A13179659E53A0D71D8959D88398F40E2077441 = E753S85750E9980P6172U369YV5427S6D8445JI4BC51U3D1930W9C4QH2UQ4ASD8QH7OYC301440T9I9I8167382G7O5243761COQF7685OE89LZ75W15M02179UJ9942W5K947PX54F9X754L25179659E53A0D71D8959D88398F40E2075686::YOEB24CZW76SK8KOPJYOA13BZCX52821BCL25M713NLWFN87L4BX7A5HF06554QM374G91A81849AFB44495C77E1F2B73B5EAC78193(); $M1626VQNP65B249Q7N89B764SW85M9YQ87QCMAE5I5437G68563Z0X9Y87G7849U38D4U0Z3LW2678LUZ3YM04MRKE26PX85OH162E7M8ZP28A42A13179659E53A0D71D8959D88398F40E2077441['post_scheduled_last_time'][$NL625401Y3WNGK83X5CP34655B614W327C6HQYLBCE02TL9QR03OCO50S1X4P69JPNW2JCREG014H760649U3148C00I51A4D12667CJ14F9V20M9R490C6SLWK73D57746CC8160496AEFC9FB306B6BA24E38413] = 0; E753S85750E9980P6172U369YV5427S6D8445JI4BC51U3D1930W9C4QH2UQ4ASD8QH7OYC301440T9I9I8167382G7O5243761COQF7685OE89LZ75W15M02179UJ9942W5K947PX54F9X754L25179659E53A0D71D8959D88398F40E2075686::PCX7EG1034523OX6W58N559L0ESMA91QN12H3E3MEC8986569217962B90EF404F8BC2A5BDE28D4CECDF4774865621($M1626VQNP65B249Q7N89B764SW85M9YQ87QCMAE5I5437G68563Z0X9Y87G7849U38D4U0Z3LW2678LUZ3YM04MRKE26PX85OH162E7M8ZP28A42A13179659E53A0D71D8959D88398F40E2077441); } $M1626VQNP65B249Q7N89B764SW85M9YQ87QCMAE5I5437G68563Z0X9Y87G7849U38D4U0Z3LW2678LUZ3YM04MRKE26PX85OH162E7M8ZP28A42A13179659E53A0D71D8959D88398F40E2077441 = E753S85750E9980P6172U369YV5427S6D8445JI4BC51U3D1930W9C4QH2UQ4ASD8QH7OYC301440T9I9I8167382G7O5243761COQF7685OE89LZ75W15M02179UJ9942W5K947PX54F9X754L25179659E53A0D71D8959D88398F40E2075686::YOEB24CZW76SK8KOPJYOA13BZCX52821BCL25M713NLWFN87L4BX7A5HF06554QM374G91A81849AFB44495C77E1F2B73B5EAC78193(); $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927 = get_option('home'); if(UI26G7ZPX97JOW432CTU77H26DL580QCC1SX64QPO8LNLL6VWL0IT8HU9I22PV0GOE889G7DX0D0EVCOM12MA273G6PDY1Z4373I8I080CK2Q3DS9UEJM023VP50G6DE39AC0B4D0AE438A73087CCBB8ECF14084()){ $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927 = str_replace('http://','https://',$EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927); } ?>

<style>
  .html{width:100%;height:500px;}
  .default_image_area span{
    margin:6px;
    padding: 6px;
    display: block;
    float: left;
    width: 165px;
    height: 165px;
  }
  .default_image_area .default_imgs{
    padding: 2px;
    display: block;
    float: left;
    cursor:pointer;
  }
  .default_image_area img{
    margin: auto;
    display: block;
  }
  .default_image_area .action{
    clear:both;
    padding:3px;
    text-align:center;
  }
  .default_image_area .action a{
    text-decoration: none;
  }
  .noselecedimg{
    border: 1px solid #CCCCCC;
  }
  .selectedimg{
    border: 4px solid #1e8cbe;
  }
</style>

<div class="wrap" style="min-height: 600px;">
 <div class="icon32"><br/></div>

 <ol class="breadcrumb" style="margin:0;">
  <li><a href="admin.php?page=autoblog-tasks">Tasks</a></li>
  <li class="active"><?php echo $E5U174Z8UD370YT381OQLFS31274Q6X24GS2478F3A4C51824AD23CB50C1C60670C0F3236->name; ?></li>
 </ol>

 <div style="margin:20px;"></div>


  <?php if(isset($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['success'])){ ?>
    <div class="alert alert-dismissible alert-success">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <?php echo $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['success']; ?>
    </div>
  <?php } ?>

  <?php if(isset($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['error'])){ ?>
    <div class="alert alert-dismissible alert-danger">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <?php echo $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['error']; ?>
    </div>
  <?php } ?>





 <h2 class="nav-tab-wrapper nav-tabs">
  <a class="nav-tab" href='javascript:;' id="tab-title-tab1"><?php echo __("Basic Settings","wp-autoblog"); ?></a>
  <a class="nav-tab" href='javascript:;' id="tab-title-tab2"><?php echo __("Extraction Settings","wp-autoblog"); ?><!-- 采集设置 --></a>
  <a class="nav-tab" href='javascript:;' id="tab-title-tab3"><?php echo __("WordPress Settings","wp-autoblog"); ?><!-- WordPress相关 --></a>
  <a class="nav-tab" href='javascript:;' id="tab-title-tab4"><?php echo __("Filter & Replacement","wp-autoblog"); ?><!--数据处理--></a>
  <a class="nav-tab" href='javascript:;' id="tab-title-tab5"><?php echo __("Custom Settings","wp-autoblog"); ?><!--自定义样式及模板--></a>
  <a class="nav-tab" href='javascript:;' id="tab-title-tab6"><?php echo __("Rewrite & Translate","wp-autoblog"); ?><!--伪原创及翻译--></a>	
 </h2>

 <div id="tab-tab1" class="div-tabs">
   <?php include_once WPAB_PATH.'/admin/autoblog.task.setting.basic.php'; ?>
 </div>

 <div id="tab-tab2" class="div-tabs ">
   <?php include_once WPAB_PATH.'/admin/autoblog.task.setting.extraction.php'; ?>
 </div>

 <div id="tab-tab3" class="div-tabs ">
   <?php include_once WPAB_PATH.'/admin/autoblog.task.setting.wp.php'; ?>
 </div>

 <div id="tab-tab4" class="div-tabs ">
   <?php include_once WPAB_PATH.'/admin/autoblog.task.setting.filter.php'; ?>
 </div>

 <div id="tab-tab5" class="div-tabs ">
   <?php include_once WPAB_PATH.'/admin/autoblog.task.setting.custom.php'; ?>
 </div>

 <div id="tab-tab6" class="div-tabs ">
   <?php include_once WPAB_PATH.'/admin/autoblog.task.setting.rewrite.php'; ?>
 </div>


 







<a href="#" id="hiddenfocus"></a>
</div> <!-- end <div class="wrap"> -->



<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" id="exampleModalLabel"><?php echo __('Alert','autoblog'); ?></h3>
      </div>
      <div class="modal-body">
          <div class="alert alert-danger" role="alert">
            <strong><?php echo __('Confirm Delete Permanently','autoblog'); ?>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo __('Cancel','autoblog'); ?></button>
        <button type="button" class="btn btn-danger"  id="deleteLevelBtn" data-level="" ><?php echo __('Delete Permanently','autoblog'); ?></button>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="fetchModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" id="exampleModalLabel"></h3>
      </div>
      <div class="modal-body">

        <div id="test_div" class="embed-responsive embed-responsive-16by9" style="overflow-y: scroll;font-weight: normal;"> <!-- class="embed-responsive embed-responsive-16by9" -->
          <!--<iframe id="O0851RR90586025U5DGEW306632WJ75HW16K3ZZVHC666068E1P6196U82888OHFRH99GC7W0XZ355987R3R6PF8ZDGAED08RU54M5U15NQFPH4070L7X516MP3BEDD60309348CAD114822115DECFAD454846" class="embed-responsive-item" src=""></iframe>-->
          <div style="text-align: center;padding: 10px;"><img src="<?php global $S0680UDT9036K4173389KRD3W2U160D17NL37GLQJQV659BMHQ42HXEO9I1U449QSQA9X356S869M6792ZXC0D3V70W3B81744J34RLI0R171585DC640CB4D004B6702C0AC600324128; echo $S0680UDT9036K4173389KRD3W2U160D17NL37GLQJQV659BMHQ42HXEO9I1U449QSQA9X356S869M6792ZXC0D3V70W3B81744J34RLI0R171585DC640CB4D004B6702C0AC600324128; ?>/images/loading.gif" ></div>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="test2Modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" id="exampleModalLabel"><?php echo __('Please enter the article URL for test','autoblog'); ?></h3>
      </div>
      <div class="modal-body">
          <div class="form-group">
            <input type="text" class="form-control" placeholder="URL" id="test_url" value="<?php echo $VGAFPC62HBWR2P0NBLW842SMR1X77PB78Y7Z27P314B9BRFNS066VL1HX487MJKGN6O4PCIH012916608B1CA731C61B3742CC3023289246['test_url']; ?>">
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo __('Close','autoblog'); ?></button>
        <button type="button" class="btn btn-primary"  id="test2submit" data-loading-text="Loading..."><?php echo __('Submit','autoblog'); ?></button>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">



jQuery(function($){
  jQuery(".panel-toggle").click(function(){jQuery(this).next(".panel-all").slideToggle('fast');});
  jQuery('[data-toggle="popover"]').popover();

});



jQuery(function($){
      jQuery('.charset').on('click',function(){
	   var val = jQuery(this).val();
	   if(val==2){
		   jQuery('#charset_name').show();
	   }else{
           jQuery('#charset_name').hide();
	   }
	
	});
});

jQuery(function($){

  jQuery('#down_attach').on('change',function(){
    var val = jQuery(this).val();
    if(val==1){
      jQuery('.down_attach_set_div').show();
    }else{
      jQuery('.down_attach_set_div').hide();
    }
  });


  jQuery('.source_type').on('click',function(){
    var val = jQuery(this).val();
    jQuery('#source_type').val(val);
    if(val==1){
      jQuery('#source_urls_1').show();
      jQuery('#source_urls_2').hide();
      jQuery('#source_urls_3').hide();
      jQuery('#source_urls_4').hide();
      jQuery('.a_rules_area').show();

    }else if(val==2){
      jQuery('#source_urls_2').show();
      jQuery('#source_urls_1').hide();
      jQuery('#source_urls_3').hide();
      jQuery('#source_urls_4').hide();
      jQuery('.a_rules_area').show();
    }else if(val==3){
      jQuery('#source_urls_3').show();
      jQuery('#source_urls_1').hide();
      jQuery('#source_urls_2').hide();
      jQuery('#source_urls_4').hide();
      jQuery('.a_rules_area').hide();
    }else if(val==4){
      jQuery('#source_urls_4').show();
      jQuery('#source_urls_1').hide();
      jQuery('#source_urls_2').hide();
      jQuery('#source_urls_3').hide();
      jQuery('.a_rules_area').hide();
    }

  });
});


jQuery('#extraction_setting .fetch_paged').on('click',function(){
  if(jQuery(this).is(':checked')){
    jQuery("#extraction_setting .fetch_paged_div").show();
  }else{
    jQuery("#extraction_setting .fetch_paged_div").hide();
  }
});

jQuery('.paged_match_type').on('change',function(){
  var val = jQuery(this).val();
  if(val==1){
    jQuery('#extraction_setting .paged_match_type_1').show();
    jQuery('#extraction_setting .paged_match_type_2').hide();
  }else{
    jQuery('#extraction_setting .paged_match_type_2').show();
    jQuery('#extraction_setting .paged_match_type_1').hide();
  }
});



jQuery('.login_set_mode').on('click',function(){
  var val = jQuery(this).val();
  if(val==0){
    jQuery('#login_set_mode_2').hide();
    jQuery('#login_set_mode_1').hide();
  }else if(val==1){
    jQuery('#login_set_mode_1').show();
    jQuery('#login_set_mode_2').hide();
  }else if(val==2){
    jQuery('#login_set_mode_2').show();
    jQuery('#login_set_mode_1').hide();
  }
});


jQuery('#download_img').on('change',function(){
  var val = jQuery(this).val();
  if(val==0){
    jQuery('.img_download_set_div').hide();
  }else{
    jQuery('.img_download_set_div').show();
  }
});

jQuery('#publish_date_mode').on('change',function(){
  var val = jQuery(this).val();
  if(val==0){
    jQuery('#publish_date_mode1').hide();
    jQuery('#publish_date_mode2').hide();
  }else if(val==1){
    jQuery('#publish_date_mode1').show();
    jQuery('#publish_date_mode2').hide();
  }else if(val==2){
    jQuery('#publish_date_mode2').show();
    jQuery('#publish_date_mode1').hide();
  }
});

jQuery('#tag_mode').on('change',function(){
  var val = jQuery(this).val();
  if(val==0){
    jQuery('#tags_div').hide();
  }else if(val==1){
    jQuery('#tags_div').show();
    jQuery('.tag_set1').show();
    jQuery('.tag_set2').hide();
  }else if(val==2){
    jQuery('#tags_div').show();
    jQuery('.tag_set2').show();
    jQuery('.tag_set1').hide();
  }
});

jQuery('.tag_mode_level').on('change',function(){
  var level = jQuery(this).attr('level');
  var val = jQuery(this).val();
  if(val==0){
    jQuery('.tags_div_level'+level).hide();
  }else if(val==1){
    jQuery('.tags_div_level'+level).show();
    jQuery('.tag_set1_level'+level).show();
    jQuery('.tag_set2_level'+level).hide();
  }else if(val==2){
    jQuery('.tags_div_level'+level).show();
    jQuery('.tag_set2_level'+level).show();
    jQuery('.tag_set1_level'+level).hide();
  }
});

jQuery('#rewrite_select').on('change',function(){
  var val = jQuery(this).val();
  if(val==1){
    jQuery('#googleTranslator').show();
    jQuery('#baiduTranslator').hide();
  }else if(val==2){
    jQuery('#baiduTranslator').show();
    jQuery('#googleTranslator').hide();
  }else{
    jQuery('#baiduTranslator').hide();
    jQuery('#googleTranslator').hide();
  }
});

jQuery('#trans_select').on('change',function(){
  var val = jQuery(this).val();
  if(val==1){
    jQuery('#googleTranslator_trans').show();
    jQuery('#baiduTranslator_trans').hide();
  }else if(val==2){
    jQuery('#baiduTranslator_trans').show();
    jQuery('#googleTranslator_trans').hide();
  }else{
    jQuery('#baiduTranslator_trans').hide();
    jQuery('#googleTranslator_trans').hide();
  }
});


jQuery('#use_default_image').on('change',function(){
  var val = jQuery(this).val();
  if(val==1){
    jQuery('.default_image_area').show();
  }else{
    jQuery('.default_image_area').hide();
  }
});


jQuery('#rewrite_origi_language_baidu').change(function(){
  var sSwitch = jQuery(this).find("option:selected").text();
  jQuery("#rewrite_origi_language_span_baidu").html(sSwitch);
});

jQuery('#rewrite_trans_language_baidu').change(function(){
  var sSwitch = jQuery(this).find("option:selected").text();
  jQuery("#rewrite_trans_language_span_baidu").html(sSwitch);
});




jQuery('.set_featured_image').on('click',function(){
  var val = jQuery(this).val();
  if(val==0){
    jQuery('#set_featured_image_div').hide();
  }else{
    jQuery('#set_featured_image_div').show();
  }
});

jQuery('.post_filter_mode').on('click',function(){
  var val = jQuery(this).val();
  if(val==0){
    jQuery('#post_filter_set_div').hide();
  }else{
    jQuery('#post_filter_set_div').show();
  }
});


V36JM7OPVS5S3B0YCX9O1192DCPD3MUY7K5960091FEV5GL278744USE4XZ00B43S03C3F0558954E0BFC0BF95DEE9AEB8118727();
A75C24V543F039Y0H5S1QL0J9Y284HI6Z7682U2M115EE1N43323O5ZPXA2KH77496F64C5BE631C14D94D57C81EB1D080E8124();
I4300Y3592GVZ0FLSHJG688FZ22JU5O826S931538Y52PM859T8PET13ZMQ3S3G87US91I1OIK40S35Q6R8UQ1J09HRTCU4FU1MSIV7OI68U82E93PFN28LS71T8BDEA0432690E4849ADCEE75EB8F281F75914();

function V36JM7OPVS5S3B0YCX9O1192DCPD3MUY7K5960091FEV5GL278744USE4XZ00B43S03C3F0558954E0BFC0BF95DEE9AEB8118727(){

  jQuery('.btn-group input[type=checkbox]').on('click',function(){
    if(jQuery(this).is(':checked')){
      jQuery(this).parent().addClass('active');
    }else{
      jQuery(this).parent().removeClass('active');
    }
  });


  jQuery('.rules_match_type').on('change',function(){
    var rules = jQuery(this).attr('data-rules');
    var val = jQuery(this).val();
    if(val==1){
      jQuery('#extraction_setting .rules_match_type_1_'+rules).show();
      jQuery('#extraction_setting .rules_match_type_2_'+rules).hide();
    }else{
      jQuery('#extraction_setting .rules_match_type_2_'+rules).show();
      jQuery('#extraction_setting .rules_match_type_1_'+rules).hide();
    }
  });

  jQuery('.outer').on('click',function(){
    var rules = jQuery(this).attr('data-rules');
    if(jQuery(this).is(':checked')){
      jQuery("#extraction_setting .outer_hidden_"+rules).val('1');
    }else{
      jQuery("#extraction_setting .outer_hidden_"+rules).val('0');
    }
  });

  jQuery('.extraction_attribute').on('click',function(){
    var rules = jQuery(this).attr('data-rules');

    if(jQuery(this).is(':checked')){
      jQuery("#extraction_setting .attribute_"+rules).attr("placeholder","<?php echo __('Enter Attribute Name','wp-autoblog'); ?>");
      jQuery("#extraction_setting .attribute_"+rules).removeAttr("disabled");
      jQuery("#extraction_setting .attribute_hidden_"+rules).attr("disabled","disabled");
      jQuery("#extraction_setting .extraction_attribute_hidden_"+rules).val('1');

    }else{
      jQuery("#extraction_setting .attribute_"+rules).val('');
      jQuery("#extraction_setting .attribute_"+rules).attr("placeholder","");
      jQuery("#extraction_setting .attribute_"+rules).attr("disabled","disabled");
      jQuery("#extraction_setting .attribute_hidden_"+rules).removeAttr("disabled");
      jQuery("#extraction_setting .extraction_attribute_hidden_"+rules).val('0');
    }

  });

  jQuery('.objective').on('click',function(){
    var rules = jQuery(this).attr('data-rules');
    var val = jQuery(this).val();
    if(val==8){
      jQuery('#extraction_setting .objective_custom_field_'+rules).show();
      jQuery('#extraction_setting .objective_var_'+rules).hide();
    }else if(val==9){
      jQuery('#extraction_setting .objective_var_'+rules).show();
      jQuery('#extraction_setting .objective_custom_field_'+rules).hide();
    }else{
      jQuery('#extraction_setting .objective_var_'+rules).hide();
      jQuery('#extraction_setting .objective_custom_field_'+rules).hide();
    }
  });

  jQuery('.rule_remove').on('click',function(){
    var rules = jQuery(this).attr('data-rules');
    jQuery("#rules_"+rules).remove();
  });


  jQuery('.level_rules_match_type').on('change',function(){
    var level = jQuery(this).attr('data-level');
    var rules = jQuery(this).attr('data-rules');
    var val = jQuery(this).val();
    if(val==1){
      jQuery("#level_rules_"+level+' .rules_match_type_1_'+rules).show();
      jQuery("#level_rules_"+level+' .rules_match_type_2_'+rules).hide();
    }else{
      jQuery("#level_rules_"+level+' .rules_match_type_2_'+rules).show();
      jQuery("#level_rules_"+level+' .rules_match_type_1_'+rules).hide();
    }
  });

  jQuery('.level_outer').on('click',function(){
    var level = jQuery(this).attr('data-level');
    var rules = jQuery(this).attr('data-rules');

    if(jQuery(this).is(':checked')){
      jQuery("#level_rules_"+level+" .outer_hidden_"+rules).val('1');
    }else{
      jQuery("#level_rules_"+level+" .outer_hidden_"+rules).val('0');
    }
  });

  jQuery('.level_extraction_attribute').on('click',function(){
    var level = jQuery(this).attr('data-level');
    var rules = jQuery(this).attr('data-rules');

    if(jQuery(this).is(':checked')){
      jQuery("#level_rules_"+level+" .attribute_"+rules).attr("placeholder","<?php echo __('Enter Attribute Name','wp-autoblog'); ?>");
      jQuery("#level_rules_"+level+" .attribute_"+rules).removeAttr("disabled");

      jQuery("#level_rules_"+level+" .attribute_hidden_"+rules).attr("disabled","disabled");
      jQuery("#level_rules_"+level+" .extraction_attribute_hidden_"+rules).val('1');
    }else{
      jQuery("#level_rules_"+level+" .attribute_"+rules).val('');
      jQuery("#level_rules_"+level+" .attribute_"+rules).attr("placeholder","");
      jQuery("#level_rules_"+level+" .attribute_"+rules).attr("disabled","disabled");

      jQuery("#level_rules_"+level+" .attribute_hidden_"+rules).removeAttr("disabled");
      jQuery("#level_rules_"+level+" .extraction_attribute_hidden_"+rules).val('0');
    }

  });


  jQuery('.level_objective').on('click',function(){
    var level = jQuery(this).attr('data-level');
    var rules = jQuery(this).attr('data-rules');
    var val = jQuery(this).val();
    if(val==8){
      jQuery("#level_rules_"+level+' .objective_custom_field_'+rules).show();
      jQuery("#level_rules_"+level+' .objective_var_'+rules).hide();
    }else if(val==9){
      jQuery("#level_rules_"+level+' .objective_var_'+rules).show();
      jQuery("#level_rules_"+level+' .objective_custom_field_'+rules).hide();
    }else{
      jQuery("#level_rules_"+level+' .objective_var_'+rules).hide();
      jQuery("#level_rules_"+level+' .objective_custom_field_'+rules).hide();
    }
  });



  jQuery('.level_rule_remove').on('click',function(){
    var level = jQuery(this).attr('data-level');
    var rules = jQuery(this).attr('data-rules');
    jQuery("#level_rules_"+level+" #level_rule_"+rules).remove();
  });
}


function A75C24V543F039Y0H5S1QL0J9Y284HI6Z7682U2M115EE1N43323O5ZPXA2KH77496F64C5BE631C14D94D57C81EB1D080E8124(){

  jQuery('#deleteModal').on('show.bs.modal', function (event) {

    var button = jQuery(event.relatedTarget);
    var level = button.data('level');

    var modal = jQuery(this);
    modal.find('#deleteLevelBtn').attr('data-level',level);
  });



  jQuery('#deleteLevelBtn').on('click',function(){
    var level = jQuery(this).attr('data-level');
    jQuery("#level_page_form_"+level+" input[name=delete]").val(1);
    jQuery("#level_page_form_"+level).submit();
  });

  jQuery('.level_a_match_type').on('click',function(){
    var level = jQuery(this).attr('data-level');
    var val = jQuery(this).val();

    if(val==1){
      jQuery('#level_page_'+level+' .a_match_1').show();
      jQuery('#level_page_'+level+' .a_match_2').hide();
    }else{
      jQuery('#level_page_'+level+' .a_match_2').show();
      jQuery('#level_page_'+level+' .a_match_1').hide();
    }
  });


}

function I4300Y3592GVZ0FLSHJG688FZ22JU5O826S931538Y52PM859T8PET13ZMQ3S3G87US91I1OIK40S35Q6R8UQ1J09HRTCU4FU1MSIV7OI68U82E93PFN28LS71T8BDEA0432690E4849ADCEE75EB8F281F75914(){

  jQuery('.a_match_type').on('click',function(){
    var rules = jQuery(this).attr('data-rules');
    var val = jQuery(this).val();
    if(val==1){
      jQuery('#a_match_1_'+rules).show();
      jQuery('#a_match_2_'+rules).hide();
    }else{
      jQuery('#a_match_2_'+rules).show();
      jQuery('#a_match_1_'+rules).hide();
    }
  });

  jQuery('.a_rule_remove').on('click',function(){
    var rules = jQuery(this).attr('data-rules');
    jQuery("#a_rules_"+rules).remove();
  });

}


jQuery(function($){
  jQuery('.btn-group input[type=radio]').on('click',function(){
    jQuery(this).parent().siblings().removeClass('active');
    jQuery(this).parent().addClass('active');
  });


});



jQuery('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
   jQuery('#hiddenfocus').focus();
})


jQuery('div.div-tabs').hide();

<?php  if(!isset($OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702)): ?>		
	   jQuery('h2 a.nav-tab').first().addClass('nav-tab-active');
	   jQuery('div.div-tabs').first().show();
<?php else:?>
       jQuery('#tab-title-tab<?php echo $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702; ?>').addClass('nav-tab-active');
       jQuery('#tab-tab<?php echo $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702; ?>').show();
<?php endif;?>

jQuery(function($){
     jQuery('h2 a.nav-tab').on('click',function(){
     jQuery('h2 a.nav-tab').removeClass('nav-tab-active');
     jQuery(this).addClass('nav-tab-active');
	 jQuery('div.div-tabs').hide();
     jQuery('#'+jQuery(this)[0].id.replace('title-','')).fadeIn("fast");
	 jQuery('#current_tab').val(jQuery(this)[0].id.replace('tab-title-',''));
	 jQuery('#hiddenfocus').focus();
	});
});


function S2HYXBGEQ76LA376V6P4PE03Y5KM9OB550276I9F2242H6F604XGH7A66SWS2MY24R5V3F60J3H39C2BC284BAAECB183049388F3BCA77748244(save_to_group){
  jQuery("#form1 input[name=save_to_group]").val(save_to_group);
  document.getElementById("form1").submit();
}

function GTO2T377H8S2ZXTIL6K82V2U9NOT6180I3P5HN65H46698B6X7E2W8GOFG21441I392990AC1DA6B155944EE9BB50C8249AE9DA018211(save_to_group){
  jQuery("#form16 input[name=save_to_group]").val(save_to_group);
  document.getElementById("form16").submit();
}

function J2I39436632Q67A68C9E95J54GOO64T66CWKEML850159LEK12VDHN9E8QE97CQ8VXEIZ67D09R6XK98895334NDB0R1A1D1179A20J3C40H6KE5X2M3JQ7OL4479TCD94SI152E3EECC5371B8C430E17B47532496C8057(save_to_group){
  if(!U76003014B85Q9Q1KBXWQ3J54174773A40S1UB90N408M20WPSG7Y5W45F6A47669E772417A71977F47D93B003C4669()){return;}
  jQuery("#form2 input[name=save_to_group]").val(save_to_group);
  document.getElementById("form2").submit();
}

function YLBX5Y051KJ3D9A0AW1690VMJ50UN12ZO8W9245C338OB6Q8K4K2C6UZ468A9Y1Q968U62S08WC649Z0I02561WJB5N16D0FC96A25FBC032510824118B70C842604(save_to_group){

  var rules_match_type = jQuery("#form3 #rules_1 .rules_match_type").val();
  if(rules_match_type==1){
    if(jQuery('.rules_match_type_1_1 .selector').val().trim()==''){
      jQuery('.rules_match_type_1_1 .selector').focus();
      return false;
    }
  }else{
    if(jQuery('.rules_match_type_2_1 .start_html').val().trim()==''){
      jQuery('.rules_match_type_2_1 .start_html').focus();
      return false;
    }
    if(jQuery('.rules_match_type_2_1 .end_html').val().trim()==''){
      jQuery('.rules_match_type_2_1 .end_html').focus();
      return false;
    }
  }


  jQuery("#form3 input[name=save_to_group]").val(save_to_group);
  document.getElementById("form3").submit();
}



function L75Q6MY23VW5641947Q7BC2AQ9L40IG2P9040303R08JEV750741156I0W0J5T5Y7HR57074Q5O20YQBXD7F4658A00B0CA5DC1078963D686F4A0FB81D54531(save_to_group){
  jQuery("#form5 input[name=save_to_group]").val(save_to_group);
  document.getElementById("form5").submit();
}







function U76003014B85Q9Q1KBXWQ3J54174773A40S1UB90N408M20WPSG7Y5W45F6A47669E772417A71977F47D93B003C4669(){
  var source_type = jQuery('#source_type').val();
  if(source_type==1||source_type==4){
    if(jQuery('#source_urls_1 textarea').val().trim()==''){
      jQuery('#source_urls_1 textarea').focus();
      return false;
    }
  }
  var check_ok = true;
  if(source_type==2){
    jQuery("#source_urls_2 input").each(function(){
      if(jQuery(this).val().trim()==''){
        jQuery(this).focus();
        check_ok=false;
      }
    });
  }
  if(!check_ok){return false;}

  if(source_type==3){
    jQuery("#source_urls_3 input").each(function(){
      if(jQuery(this).val().trim()==''){
        jQuery(this).focus();
        check_ok=false;
      }
    });
  }
  if(!check_ok){return false;}

  var a_match_type = jQuery('#a_match_type_0').val();
  if(a_match_type==1){
    if(jQuery('#a_match_1_0 input').val().trim()==''){
      jQuery('#a_match_1_0 input').focus();
      return false;
    }
  }
  if(a_match_type==2){
    if(jQuery('#a_match_2_0 input').val().trim()==''){
      jQuery('#a_match_2_0 input').focus();
      return false;
    }
  }
  return true;
}


jQuery('#test1btn').on('click',function(){
  if(!U76003014B85Q9Q1KBXWQ3J54174773A40S1UB90N408M20WPSG7Y5W45F6A47669E772417A71977F47D93B003C4669()){return;}
  jQuery("#form2 input[name=saction]").val(1);
  document.getElementById("form2").submit();
});

jQuery('#test2btn').on('click',function(){

  var rules_match_type = jQuery("#form3 #rules_1 .rules_match_type").val();
  if(rules_match_type==1){
    if(jQuery('.rules_match_type_1_1 .selector').val().trim()==''){
      jQuery('.rules_match_type_1_1 .selector').focus();
      return false;
    }
  }else{
    if(jQuery('.rules_match_type_2_1 .start_html').val().trim()==''){
      jQuery('.rules_match_type_2_1 .start_html').focus();
      return false;
    }
    if(jQuery('.rules_match_type_2_1 .end_html').val().trim()==''){
      jQuery('.rules_match_type_2_1 .end_html').focus();
      return false;
    }
  }

  jQuery('#test2Modal').modal('show');
});

jQuery('#test2submit').on('click',function(){
  if(document.getElementById("test_url").value == ''){
    document.getElementById("test_url").focus();
    return;
  }
  jQuery("#form3 input[name=saction]").val(2);
  jQuery("#form3 input[name=test_url]").val(jQuery("#test_url").val());
  document.getElementById("form3").submit();
});





function FM772329T09YJJE83Y99X071JN4H8I05J551NZ94778NS25721IE9Q00ZHT9R13EA6MCX5C0S4O4YD5U0U8JI0WB326I967C3VI7404R0J5863O6X0O13NE08693867297AB4C39B450EF09ACCE2FC7426506(){
  var a_rules_count = parseInt(jQuery('#a_rules_count').val());
  var btn = jQuery('#addMoreURLLevelBtn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=addMoreURLLevelAct&rules_count="+a_rules_count,
    dataType: "json",
    beforeSend: function(json){

    },
    success: function(json){

      jQuery("#source_setting_table").append(json[0]);
      jQuery('#a_rules_count').val(a_rules_count+1);
      I4300Y3592GVZ0FLSHJG688FZ22JU5O826S931538Y52PM859T8PET13ZMQ3S3G87US91I1OIK40S35Q6R8UQ1J09HRTCU4FU1MSIV7OI68U82E93PFN28LS71T8BDEA0432690E4849ADCEE75EB8F281F75914();
      btn.html(btnName);
      btn.removeAttr('disabled');

    }

  });
}


function P02AHIMBN3O33JZSF7M3403390572HI39CS24ENW4V5N84A992SE38A50QVT325Z65XL925XZ9UJ3J30FK976G6KX050FDKQ4F1DK26KVP4MO3Y1AB38B165A8B0A9AAF2790EA01246AE69762C4977(){
  var rules_count = parseInt(jQuery('#rules_count').val())+1;
  var btn = jQuery('#addRulesBtn');
  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');
  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=addNewRulesAct&rules_count="+rules_count,
    dataType: "json",
    beforeSend: function(json){

    },
    success: function(json){

      jQuery("#rules").append(json[0]);
      jQuery('#rules_count').val(rules_count);
      V36JM7OPVS5S3B0YCX9O1192DCPD3MUY7K5960091FEV5GL278744USE4XZ00B43S03C3F0558954E0BFC0BF95DEE9AEB8118727();

      jQuery("#level_"+rules_count).append('<?php echo $DR0I27V246961T3R67529D8FZH0I8KEN2551AE87257AECA70E8DDBD01E0BE164B99591;?>');

      btn.html(btnName);
      btn.removeAttr('disabled');

    }

  });
}

function RTBG1Z6TZO5G68R7580H4155SU5I5LAOS6EOZA163G25798TT36VU4RMCK1LZTH1NBK66O2N432504FEY6MT1B8L55Z705D0FJDN373L5H5EF9X5N80S2283975PC03187EE6E84FE8E029A87EC9D73A841731943(k){
  var rules_count = parseInt(jQuery('#level_rules_count_'+k).val())+1;
  var btn = jQuery('#addNewRulesInLevelBtn'+k);

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=addNewLevelRulesAct&level="+k+"&rules_count="+rules_count,
    dataType: "json",
    beforeSend: function(json){

    },
    success: function(json){
      jQuery("#level_rules_"+k).append(json[0]);
      jQuery('#level_rules_count_'+k).val(rules_count);
      V36JM7OPVS5S3B0YCX9O1192DCPD3MUY7K5960091FEV5GL278744USE4XZ00B43S03C3F0558954E0BFC0BF95DEE9AEB8118727();

      jQuery("#level"+k+"_"+rules_count).append('<?php echo $DR0I27V246961T3R67529D8FZH0I8KEN2551AE87257AECA70E8DDBD01E0BE164B99591;?>');

      btn.html(btnName);
      btn.removeAttr('disabled');
    }

  });
}

function Y6NQHBB9UU7YPCNX732O60MI16C76914I8I35X8C7DA928159D664764723557BF44C3BA5775(){
  var level_page_count = parseInt(jQuery('#level_page_count').val())+1;
  var last_level = parseInt(jQuery('#last_level').val())+1;
  var btn = jQuery('#addNextPageLevelBtn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');


  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=addNextPageLevelAct&level_page_count="+level_page_count+"&last_level="+last_level+"&task_id=<?php echo $NL625401Y3WNGK83X5CP34655B614W327C6HQYLBCE02TL9QR03OCO50S1X4P69JPNW2JCREG014H760649U3148C00I51A4D12667CJ14F9V20M9R490C6SLWK73D57746CC8160496AEFC9FB306B6BA24E38413; ?>"+"&group_id=<?php echo $E5U174Z8UD370YT381OQLFS31274Q6X24GS2478F3A4C51824AD23CB50C1C60670C0F3236->group_id; ?>",
    dataType: "json",
    beforeSend: function(json){

    },
    success: function(json){
      jQuery("#level_page_div").append(json[0]);
      jQuery('#level_page_count').val(level_page_count);
      jQuery('#last_level').val(last_level);
      A75C24V543F039Y0H5S1QL0J9Y284HI6Z7682U2M115EE1N43323O5ZPXA2KH77496F64C5BE631C14D94D57C81EB1D080E8124();
      V36JM7OPVS5S3B0YCX9O1192DCPD3MUY7K5960091FEV5GL278744USE4XZ00B43S03C3F0558954E0BFC0BF95DEE9AEB8118727();

      jQuery("#level"+level_page_count+"_1").append('<?php echo $DR0I27V246961T3R67529D8FZH0I8KEN2551AE87257AECA70E8DDBD01E0BE164B99591;?>');

      btn.html(btnName);
      btn.removeAttr('disabled');

      jQuery("#level_page_"+level_page_count+" .panel-toggle").click(function(){jQuery(this).next(".panel-all").slideToggle('fast');});

    }

  });
}

function G0P8347P3VE9W170FR8H67I73PI305A8Y5I92QN068A96X2K0Y999VK1W14X6LVQM0Y79V43279239P1N6775MM50BUDRBE9E413B3EDFC5306586294477ADA2147030(){
  var btn = jQuery('#addLoginParaBtn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=addLoginParaAct",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#login_para_div").append(json[0]);
      NJ1O584TE15KTJ4R48V3T1L61738W2W85336X2O372AIH5011D6V3Z7M22548GU1Z89CA1FCEO969T5I8118X212ABGA5RT993I7U6567512W4YQ45247HDA2F7AFAF4BEB9F8A07B789D743104E87C8C2190();

      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function NJ1O584TE15KTJ4R48V3T1L61738W2W85336X2O372AIH5011D6V3Z7M22548GU1Z89CA1FCEO969T5I8118X212ABGA5RT993I7U6567512W4YQ45247HDA2F7AFAF4BEB9F8A07B789D743104E87C8C2190(){
  jQuery('.deleteLoginParaBtn').on('click',function(){
    jQuery(this).parent().remove();
  });
}
NJ1O584TE15KTJ4R48V3T1L61738W2W85336X2O372AIH5011D6V3Z7M22548GU1Z89CA1FCEO969T5I8118X212ABGA5RT993I7U6567512W4YQ45247HDA2F7AFAF4BEB9F8A07B789D743104E87C8C2190();


function Y9088MK6798G07CAE6TQ22O6WMSSB131X6C10X9T1F9Z14QL1Z8WQ88639T786204NAT27I5P4RU27DXLEL8YG6L63N299H12PH85QBX86NRN509442EEB4CA2FCB84EE267F2B0DA19AE2B60621658(){
  var btn = jQuery('#addCustomFieldsBtn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=addCustomFieldsAct",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#custom_fields_div").append(json[0]);
      G449J454I0H2G3W3848TZYMU1FV68G91Z5108K8FMVJ1I77520G97L6534KB55V87Z60EHT1B1X784Y6601R7BK2ZT2Q9K4DW4I4LL8I74O344KFP1QR248950Q44G1SZK486X1AD9F38568153CFE51ABFE707C1672B88988();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function F393T33LV4QC4N0OICGQ6YBQ5G53GIW42553U43CYW6888PW294F5MFRYDR19383F945747255RK3N5513RQ2N5M4419SN85CRBDBC109357CFY43I4M1479AEC7A424C340DDBDEEBF54D02FFCAED1E9547(){
  var btn = jQuery('#addDownloadTagsBtn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=addDownloadTagsAct",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#download_tags_div").append(json[0]);
      V7WO3N29YH4T4PUW575053A3ZGKV762BY9K0T52NCMQ1F81LVUOVX3956IRKD12227V01V7584881596YA8QA93OTBR63E73C13409PT35QBX59PG75LZI3H41HQMOI6UWXX6E4X4BAD25C657FEDEA86770E18359D71BD99520();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function NCL21ALN1G82IA35N8F43857KWTZ3WC04KDQ4AT9JR9Q87C8N4T0IIK988LB1UU38141F73VRU93U7ZCGOUHM9U8042484HZ86F7E9P2LUPE643407B0Z100M6LR2401M050E26E22F00931F45E32616A3E9F1F040B8207(level){
  var btn = jQuery('#addCustomFieldsBtn'+level);

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=addCustomFieldsAct",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#custom_fields_div"+level).append(json[0]);
      G449J454I0H2G3W3848TZYMU1FV68G91Z5108K8FMVJ1I77520G97L6534KB55V87Z60EHT1B1X784Y6601R7BK2ZT2Q9K4DW4I4LL8I74O344KFP1QR248950Q44G1SZK486X1AD9F38568153CFE51ABFE707C1672B88988();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function G449J454I0H2G3W3848TZYMU1FV68G91Z5108K8FMVJ1I77520G97L6534KB55V87Z60EHT1B1X784Y6601R7BK2ZT2Q9K4DW4I4LL8I74O344KFP1QR248950Q44G1SZK486X1AD9F38568153CFE51ABFE707C1672B88988(){
  jQuery('.deleteCustomFieldsBtn').on('click',function(){
    jQuery(this).parent().remove();
  });
}
G449J454I0H2G3W3848TZYMU1FV68G91Z5108K8FMVJ1I77520G97L6534KB55V87Z60EHT1B1X784Y6601R7BK2ZT2Q9K4DW4I4LL8I74O344KFP1QR248950Q44G1SZK486X1AD9F38568153CFE51ABFE707C1672B88988();

function V7WO3N29YH4T4PUW575053A3ZGKV762BY9K0T52NCMQ1F81LVUOVX3956IRKD12227V01V7584881596YA8QA93OTBR63E73C13409PT35QBX59PG75LZI3H41HQMOI6UWXX6E4X4BAD25C657FEDEA86770E18359D71BD99520(){
  jQuery('.deleteDownloadTagsBtn').on('click',function(){
    jQuery(this).parent().remove();
  });
}
V7WO3N29YH4T4PUW575053A3ZGKV762BY9K0T52NCMQ1F81LVUOVX3956IRKD12227V01V7584881596YA8QA93OTBR63E73C13409PT35QBX59PG75LZI3H41HQMOI6UWXX6E4X4BAD25C657FEDEA86770E18359D71BD99520();




function Z7KWU74PV817J320E63K52L13YGB1RLF4PZX0A834556FW5X4E8YQ8C41Q5E96D034QC5I45Z15K66ORWEJ0882TN9XK8654FE13C9C2B2E6B62DECA806E0AB320193(){
  var btn = jQuery('#add_css_filter_rules_btn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=add_css_filter_rules_act&rules_count=<?php echo $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443; ?>",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#css_content_filter_div").append(json[0]);
      SQ0GR8LB5QGLAX0SN7M298B5MAF3S45O0F6QHUS9VC5RP9RWVB106Y5X0BT0OC787D91F239I07D0L52P81PZ08QB94G7205U2C99CBCTD3LK12DA3619341403FF745C4BDCF571232AD5C7644();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function ZNL4GY0FQ3D982AFR2KJIQ074J12G3DY0I27Q3L471ZET65B0675A85E7BFBF53DC40C5E02CA91E63366(){
  var btn = jQuery('#add_keyword_filter_rules_btn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=add_keyword_filter_rules_act&rules_count=<?php echo $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443; ?>",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#keyword_content_filter_div").append(json[0]);
      SQ0GR8LB5QGLAX0SN7M298B5MAF3S45O0F6QHUS9VC5RP9RWVB106Y5X0BT0OC787D91F239I07D0L52P81PZ08QB94G7205U2C99CBCTD3LK12DA3619341403FF745C4BDCF571232AD5C7644();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function CH5DK78WCE18SZ61723T9002P17RB8329324A2LZ86H928W8C6KHF7766O0N7524AC1380CCA3F6C66629FE09F5ECF6609709(){
  var btn = jQuery('#add_html_tag_rules_btn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=add_html_tag_rules_act&rules_count=<?php echo $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443; ?>",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#html_tag_filter_div").append(json[0]);
      SQ0GR8LB5QGLAX0SN7M298B5MAF3S45O0F6QHUS9VC5RP9RWVB106Y5X0BT0OC787D91F239I07D0L52P81PZ08QB94G7205U2C99CBCTD3LK12DA3619341403FF745C4BDCF571232AD5C7644();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function VN4PWM09190HI083IN91Q3K8N0E57M07CAU9FN46S200A5RD15E5ZMNPTL0I35TEN05Z6858LWHADU94DK0BDMCH58JQ3N0L2YEJVIEKFLKEFW075NRTEV2T85Y65JL0CAE58A5B6E3BAB36300598D6D08B3C660780(){
  var btn = jQuery('#add_css_replace_rules_btn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=add_css_replace_rules_act&rules_count=<?php echo $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443; ?>",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#css_replace_div").append(json[0]);
      QFM9C35872995SVTLQ307N16B59HH09Z8Z3H26HV0857P5R6586H9WVJI0OVGYNN454VXN636710T0N602Z9CWY0O07L4E61E0327574XQGK5154K88433B82673546FC4B728002796462CD18265();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function WN502K9J2YOP7PWP668KU5114B9337681AQV26C469J876H55636N2QB5PQ37N71908SARZF81VA1W1782CG04B353YEVHM882T90LX0Q80WZ9Y8D7WK9MQWJ7H7A862TJU8HED4863RE8720165950B8BDAE50AA8C9723B8358D08871(){
  var btn = jQuery('#add_keyword_replace_rules_btn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=add_keyword_replace_rules_act&rules_count=<?php echo $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443; ?>",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#keyword_replace_div").append(json[0]);
      QFM9C35872995SVTLQ307N16B59HH09Z8Z3H26HV0857P5R6586H9WVJI0OVGYNN454VXN636710T0N602Z9CWY0O07L4E61E0327574XQGK5154K88433B82673546FC4B728002796462CD18265();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function C1E21IAN6E16X61N579AM61946Z6UH84GR69YPV9P81T494579M26JF4YQ8673948B374C4AC4514B8A2A865AE2CEC11752(){
  var btn = jQuery('#add_attr_set_rules_btn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=add_attr_set_rules_act&rules_count=<?php echo $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443; ?>",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#attr_set_div").append(json[0]);
      SQ0GR8LB5QGLAX0SN7M298B5MAF3S45O0F6QHUS9VC5RP9RWVB106Y5X0BT0OC787D91F239I07D0L52P81PZ08QB94G7205U2C99CBCTD3LK12DA3619341403FF745C4BDCF571232AD5C7644();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}


function U1Q96VE916JJEFO76K1IWH2VJ1E4R93X16KQ412Q65O1PM1FF2K9H0640GG577JGL3O759D43MDU0683854MS6WNL8KAKDRX79C60R2C4896E3CE9E44AC0037F896FE8E0E8DBB2049(){
  var btn = jQuery('#add_insert_content_rules_btn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=add_insert_content_rules_act&rules_count=<?php echo $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443; ?>",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#insert_content_table").append(json[0]);
      O1JI22P55295G99Y1N6ZXD515W7J37WK3S961R2R059562627W197TX44VQT1FYJ9JY93JKN04DK48E87206FJY6C8OOA6FXN7QD96331OL4663P932R3FX5C9B71035C53B36F5D7CBEDE265C152F0359();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}

function HJF889NKUS54TAQ9780J1O894E0VHB7D8J8XJ8D2AD7113HB6FF94C1Q23417C332D6046F4520860C6F4B40D4678834(){
  var btn = jQuery('#add_prefix_suffix_rules_btn');

  var btnName = btn.html();
  btn.html('Loading...');
  btn.attr('disabled','true');

  jQuery.ajax({
    type: "GET",
    url: "<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",
    data: "ab=add_prefix_suffix_rules_act&rules_count=<?php echo $W0F6NOZ8LU30K8D7Q07L752HNO6E479181F33476A32562E0F92D0A73435EB189EAB4B6443; ?>",
    dataType: "json",
    beforeSend: function(json){
    },
    success: function(json){
      jQuery("#prefix_suffix_table").append(json[0]);
      O1JI22P55295G99Y1N6ZXD515W7J37WK3S961R2R059562627W197TX44VQT1FYJ9JY93JKN04DK48E87206FJY6C8OOA6FXN7QD96331OL4663P932R3FX5C9B71035C53B36F5D7CBEDE265C152F0359();
      btn.html(btnName);
      btn.removeAttr('disabled');
    }
  });
}


function SQ0GR8LB5QGLAX0SN7M298B5MAF3S45O0F6QHUS9VC5RP9RWVB106Y5X0BT0OC787D91F239I07D0L52P81PZ08QB94G7205U2C99CBCTD3LK12DA3619341403FF745C4BDCF571232AD5C7644(){
  jQuery('.inputdeleteBtn').on('click',function(){
    jQuery(this).parent().remove();
  });
}
SQ0GR8LB5QGLAX0SN7M298B5MAF3S45O0F6QHUS9VC5RP9RWVB106Y5X0BT0OC787D91F239I07D0L52P81PZ08QB94G7205U2C99CBCTD3LK12DA3619341403FF745C4BDCF571232AD5C7644();

function QFM9C35872995SVTLQ307N16B59HH09Z8Z3H26HV0857P5R6586H9WVJI0OVGYNN454VXN636710T0N602Z9CWY0O07L4E61E0327574XQGK5154K88433B82673546FC4B728002796462CD18265(){
  jQuery('.inputdeleteBtn1').on('click',function(){
    jQuery(this).parent().parent().remove();
  });
}
QFM9C35872995SVTLQ307N16B59HH09Z8Z3H26HV0857P5R6586H9WVJI0OVGYNN454VXN636710T0N602Z9CWY0O07L4E61E0327574XQGK5154K88433B82673546FC4B728002796462CD18265();

function O1JI22P55295G99Y1N6ZXD515W7J37WK3S961R2R059562627W197TX44VQT1FYJ9JY93JKN04DK48E87206FJY6C8OOA6FXN7QD96331OL4663P932R3FX5C9B71035C53B36F5D7CBEDE265C152F0359(){
  jQuery('.trdeleteBtn').on('click',function(){
    jQuery(this).parent().parent().parent().parent().remove();
  });
}
O1JI22P55295G99Y1N6ZXD515W7J37WK3S961R2R059562627W197TX44VQT1FYJ9JY93JKN04DK48E87206FJY6C8OOA6FXN7QD96331OL4663P932R3FX5C9B71035C53B36F5D7CBEDE265C152F0359();

jQuery(".default_imgs").click( function() {

  var id = jQuery(this).attr("id");
  var lastValue = jQuery("#img_"+id).val();


  if(lastValue==0){
    jQuery(this).removeClass("noselecedimg");
    jQuery(this).addClass("selectedimg");
    jQuery("#img_"+id).val(id);
  }else{
    jQuery(this).removeClass("selectedimg");
    jQuery(this).addClass("noselecedimg");
    jQuery("#img_"+id).val(0);
  }

});



<?php if(isset($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['saction'])&&$A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['saction']==1){ ?>

jQuery( document ).ready(function() {
  jQuery('#fetchModal').modal('show');

  var data = new Object();
  data.ab='st';
  data.id=<?php echo $NL625401Y3WNGK83X5CP34655B614W327C6HQYLBCE02TL9QR03OCO50S1X4P69JPNW2JCREG014H760649U3148C00I51A4D12667CJ14F9V20M9R490C6SLWK73D57746CC8160496AEFC9FB306B6BA24E38413; ?>;
  jQuery.get("<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",data,function(json) {
    jQuery("#test_div").html(json);
    //jQuery("#fetchModal .modal-title").html(json[1]);
  });


});


<?php } ?>


<?php if(isset($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['saction'])&&$A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['saction']==2){ ?>

jQuery( document ).ready(function() {
  jQuery('#fetchModal').modal('show');

  var data = new Object();
  data.ab='et';
  data.id=<?php echo $NL625401Y3WNGK83X5CP34655B614W327C6HQYLBCE02TL9QR03OCO50S1X4P69JPNW2JCREG014H760649U3148C00I51A4D12667CJ14F9V20M9R490C6SLWK73D57746CC8160496AEFC9FB306B6BA24E38413; ?>;
  jQuery.get("<?php echo $EU71J15600NE939EEL5438VZ2311SE054KFE763558UP359MDSI0V6A64LL819T0D8AA6C1951E8DB2FD2403CE0191526C16574927; ?>",data,function(json) {
    jQuery("#test_div").html(json);
    //jQuery("#fetchModal .modal-title").html(json[1]);

    jQuery('.showHtml').on('click',function(){

      var level = jQuery(this).attr('level');

      if(jQuery('#showHtml2_'+level).attr('show')==0){
        jQuery('#showHtml2_'+level).show();
        jQuery('#showHtml1_'+level).hide();
        jQuery('#showHtml2_'+level).attr('show',1);
        jQuery('#showHtml1_'+level).attr('show',0);
      }else if(jQuery('#showHtml1_'+level).attr('show')==0){
        jQuery('#showHtml1_'+level).show();
        jQuery('#showHtml2_'+level).hide();
        jQuery('#showHtml1_'+level).attr('show',1);
        jQuery('#showHtml2_'+level).attr('show',0);
      }


    });

  });




});


<?php } ?>

</script>