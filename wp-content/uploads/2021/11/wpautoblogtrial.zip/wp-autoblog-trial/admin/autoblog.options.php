<?php
 $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239 = B613ZGX5MXYUGY59910JB3QB897RREN1E7D226Z65OEU89CP45Y741EB66B017D369EF86CF1F9849D428765298::U42664HQSJCC849FG2521HL0AR09847X9O5O10B94OA6GW7552937GG3292U1C9ESE7P2VTO7ADD7CAA0F0463AB0105AB6E0AC7294C9298(); if(isset($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showTab'])){ $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702= $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showTab']; } if(isset($_GET['tab'])){ $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702= $_GET['tab']; } $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696 = unserialize(get_option('wp-autoblog-options')); if(isset($_GET['del_wm_name'])){ $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702= 5; if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[8][$_GET['del_wm_name']])){ $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[8][$_GET['del_wm_name']]=null; unset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[8][$_GET['del_wm_name']]); $XT5X96X12JTHO7E2GAQ3TW47E7HMTPGNT5HM34X68U4998LJU5LETPP69B19821D734CK0265Z5B0C0151B1204023E09DF0DE1FDD2630A608340 = serialize($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696); update_option('wp-autoblog-options',$XT5X96X12JTHO7E2GAQ3TW47E7HMTPGNT5HM34X68U4998LJU5LETPP69B19821D734CK0265Z5B0C0151B1204023E09DF0DE1FDD2630A608340); } } if(isset($_GET['del_proxy_name'])){ $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702= 6; if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[9][$_GET['del_proxy_name']])){ $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[9][$_GET['del_proxy_name']]=null; unset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[9][$_GET['del_proxy_name']]); $XT5X96X12JTHO7E2GAQ3TW47E7HMTPGNT5HM34X68U4998LJU5LETPP69B19821D734CK0265Z5B0C0151B1204023E09DF0DE1FDD2630A608340 = serialize($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696); update_option('wp-autoblog-options',$XT5X96X12JTHO7E2GAQ3TW47E7HMTPGNT5HM34X68U4998LJU5LETPP69B19821D734CK0265Z5B0C0151B1204023E09DF0DE1FDD2630A608340); } } ?>


<style>
  .watermark_preview_pic img{
    -webkit-box-shadow: 0 0 7px #999999;
    box-shadow: 0 0 7px #999999;
    -moz-box-shadow: 0 0 7px #999999;
    border: 6px solid #FFFFFF;
    margin-top: 10px;
    max-width: 83%;
  }
</style>

<div class="wrap">
  <div class="icon32"><br/></div>


  <div style="margin:20px;"></div>


  <?php
 $CD6C18SM4R6M50P9GZX3R84X7BUL7192D7E6D55BA379A13D08C25D15FAF2A23B9033 = strtotime(current_time( 'mysql' )); $U54389101EY55ZG83MP2K8F91AV7ZIT83935OQ6467676S6WW77I8298G1UH760YP893X3L8F5XV46X1H0JZ018C1221160B6730C56212A35B97A0FA8BC5295408 = strtotime('2017-11-2'); ?>

  <?php if(isset($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['success'])){ ?>
    <div class="alert alert-dismissible alert-success">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <?php echo $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['success']; ?>
    </div>
  <?php } ?>

  <?php if(isset($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['error'])){ ?>
    <div class="alert alert-dismissible alert-danger">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <?php echo $A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['error']; ?>
    </div>
  <?php } ?>



  <h2 class="nav-tab-wrapper nav-tabs">
    <a class="nav-tab" href='javascript:;' id="tab-title-tab1"><?php echo __("Basic Options","wp-autoblog"); ?></a>
    <a class="nav-tab" href='javascript:;' id="tab-title-tab2"><?php echo __("Translator Options","wp-autoblog"); ?></a>
    <a class="nav-tab" href='javascript:;' id="tab-title-tab3"><?php echo __("Rewrite Options","wp-autoblog"); ?></a>
    <a class="nav-tab" href='javascript:;' id="tab-title-tab4"><?php echo __("Cloud Storage Options","wp-autoblog"); ?></a>
    <a class="nav-tab" href='javascript:;' id="tab-title-tab5"><?php echo __("Watermark Options","wp-autoblog"); ?></a>
    <a class="nav-tab" href='javascript:;' id="tab-title-tab6"><?php echo __("Proxy Options","wp-autoblog"); ?></a>
    <!--
    <a class="nav-tab" href='javascript:;' id="tab-title-tab7"><?php echo __("Other Options","wp-autoblog"); ?></a>
    -->
  </h2>

  <div id="tab-tab1" class="div-tabs">
    <div style="margin:16px;"></div>
    <div id="poststuff">
      <div id="post-body" class="metabox-holder columns-2">
        <div id="post-body-content">

          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Basic Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" >
              <form id="form1"  method="post" action="admin.php?page=autoblog-options">
                <input type="hidden" name="action" value="form1" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">
                    <tr>
                      <td class="setName">
                        <label><?php echo __("Update Method","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <select class="input-default" name="update_method" id="update_method" onchange="UX2ZK6PY9588ZOL4S231P712061W4KR4TCX2D2M21TK0P193R3LM03L5J77M44346XF22UY52YPZ3DAAE6EB8455514DC6B78155D198CAAF968603(this.value)">
                          <option value="0" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[0]==0) echo 'selected="true"'; ?> >
                            <?php echo __('Automatically check for updates after pages load','wp-autoblog'); ?>
                          </option>
                          <option value="1" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[0]==1) echo 'selected="true"'; ?> >
                            <?php echo __('Cron job or manual updates','wp-autoblog'); ?>
                          </option>
                        </select>

                        <div id="cron" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[0]!=1)echo 'style="display:none;"' ?> >

                          <?php
 global $wpdb; $E5U174Z8UD370YT381OQLFS31274Q6X24GS2478F3A4C51824AD23CB50C1C60670C0F3236 = $wpdb->get_row("select t1.auto_fetch,t1.last_check_time,t1.run_interval from $M1MY7976IB66YUN408957Y1Y9156WNE7G9S34633034H9256ZGX40640T4Y4392316VE3O9KE2394VD6ZG92J6H3G5MOGH759LGKDAD335D3718B6DD87D9EE07E43DF3C1C8650 t1 where in_trash = 0"); if($E5U174Z8UD370YT381OQLFS31274Q6X24GS2478F3A4C51824AD23CB50C1C60670C0F3236->auto_fetch==0){ ?>

                            <p><span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Current No Auto Running Task, this settings will no effective','wp-autoblog'); ?></span></p>

                          <?php
 } ?>

                          <p><?php echo __('If you want to use a cron job, you can perform scheduled updates by sending regularly-scheduled requests to','wp-autoblog'); ?>  <code><a href="<?php echo get_bloginfo('url'); ?>/?autoblog_run=1" target="_blank" ><?php echo get_bloginfo('url'); ?>/?autoblog_run=1</a></code> <?php echo __('For example, inserting the following line in your crontab:','wp-autoblog'); ?></p>
                          <p><pre style="font-size: 0.80em"><code>*/10 * * * * /usr/bin/curl --silent <?php echo get_bloginfo('url'); ?>/?autoblog_run=1</code></pre></p>
                          <p><?php echo __('will check in every 10 minutes and check for updates on any activated tasks that are ready to be polled for updates.','wp-autopost'); ?></p>
                        </div>

                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Time Limit on Updates","wp-autoblog"); ?></label>
                        <p class="desc"><?php echo __("Recommend the use of 0, which means that no time limit.","wp-autoblog"); ?></p>
                      </td>
                      <td>
                        <div class="input-group" style="width:200px;">
                          <input type="text" class="form-control"  name="time_limit" id="time_limit" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[1]; ?>" >
                          <div class="input-group-addon"><?php echo __("seconds","wp-autoblog"); ?></div>
                        </div>
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("How many tasks can run simultaneously","wp-autoblog"); ?></label>
                        <p class="desc"><span style="color: red;"><b><?php echo __("Waring","wp-autoblog"); ?></b>: </span> <?php echo __("Recommend set to 1, or may affect server performance","wp-autoblog"); ?></p>
                      </td>
                      <td>
                        <div class="input-group" style="width:100px;">
                          <input type="text" class="form-control"  name="run_task_num" id="run_task_num" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[2]; ?>" >
                        </div>
                      </td>
                    </tr>


                  </table>
                </div> <!-- /panel-body -->

              </form>


              <div class="panel-footer">
                <a class="btn btn-primary" data-loading-text="Loading..." onclick="S2HYXBGEQ76LA376V6P4PE03Y5KM9OB550276I9F2242H6F604XGH7A66SWS2MY24R5V3F60J3H39C2BC284BAAECB183049388F3BCA77748244()" ><?php echo __('Save'); ?> </a>
              </div>
            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


        </div> <!-- /post-body-content -->
      </div><!-- /post-body -->
    </div><!-- /poststuff -->
  </div>


  <div id="tab-tab2" class="div-tabs ">
    <div style="margin:16px;"></div>

    <?php
 ?>


    <div id="poststuff">
      <div id="post-body" class="metabox-holder columns-2">
        <div id="post-body-content">


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Google Cloud Translation (Google Neural Machine Translation) Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==10))echo 'style="display:none;"' ?>>
              <form id="form12"  method="post" action="admin.php?page=autoblog-options">
                <input type="hidden" name="action" value="form12" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("API key","wp-autoblog"); ?></label>
                        <p class="desc"><a href="https://support.google.com/cloud/answer/6158862?hl=en" target="_blank">More details</a></p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="api_key"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[14][0]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td colspan="2">
                        <p><a href="https://cloud.google.com/translate/" target="_blank">Apply Google Cloud Translation</a></p>
                        <p>
                          By default, when you make a translation request to the Google Cloud Translation API, your text is translated using the NMT ( <a href="https://research.googleblog.com/2016/09/a-neural-network-for-machine.html" target="_blank">Neural Machine Translation</a> ) model. If the NMT model is not supported for the requested language translation pair, the PBMT ( Phrase-Based Machine Translation ) model is used.
                        </p>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If set up correctly, the following language can be translated into other languages', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label><?php echo __("Original Language","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <select class="input-default" name="fromLanguage" ><?php $D544052OH3N9KGA4GJRQ31Y60537A0GKIEQ78N572T2EKCB8336963P720648OD8B5DACAF910EA628737C997694C36951632 = ($_POST['fromLanguage']!='')?$_POST['fromLanguage']:'en'; echo BFUA2TUJS7817B7TH395UK5J4PY0K9U5354P565U9N9M2XYTE85IQS0FP9LC43C724C0BAF67BF52A6EA8CED4BC3075269::T87LL6FJ7JY2C0TI34EMM33BZ877055OWKUR50T5QQB2606GXVJ07091X42TX9TH9637507F14BD49ADF1E9076223AC9DE25237($D544052OH3N9KGA4GJRQ31Y60537A0GKIEQ78N572T2EKCB8336963P720648OD8B5DACAF910EA628737C997694C36951632); ?></select>
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <textarea style="width: 100%" rows="5"  name="src_text" ><?php echo (isset($_POST['src_text'])&&$_POST['src_text']!='')?stripslashes($_POST['src_text']):'Hello world!'; ?></textarea>
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Translated into","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <select class="input-default" name="toLanguage" ><?php $N2A2G9MF2O178KM645254782HF43646EF97219G61907WZCYA328961U8K9NI12EZJS7W8J6259578609237X5YDR29A7200I6BD3TBIE108P56PF3FCC6E730A750D2EBF37320744BFBDA1696 = ($_POST['toLanguage']!='')?$_POST['toLanguage']:'zh';echo BFUA2TUJS7817B7TH395UK5J4PY0K9U5354P565U9N9M2XYTE85IQS0FP9LC43C724C0BAF67BF52A6EA8CED4BC3075269::T87LL6FJ7JY2C0TI34EMM33BZ877055OWKUR50T5QQB2606GXVJ07091X42TX9TH9637507F14BD49ADF1E9076223AC9DE25237($N2A2G9MF2O178KM645254782HF43646EF97219G61907WZCYA328961U8K9NI12EZJS7W8J6259578609237X5YDR29A7200I6BD3TBIE108P56PF3FCC6E730A750D2EBF37320744BFBDA1696); ?></select>
                      </td>
                    </tr>

                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Trial version this settings will not working, use this featured please upgrade to full version','wp-autoblog'); ?></span>
                </div>
                <div class="panel-footer">
                  <button class="btn btn-primary" data-loading-text="Loading..."  disabled="true"><?php echo __('Save'); ?> </button>
                  <button class="btn btn-primary" data-loading-text="Loading..."  disabled="true"><?php echo __('Test Translate','wp-autoblog'); ?> </button>
                </div>


              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->

          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("YouDao Translator Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==15))echo 'style="display:none;"' ?>>
              <form id="form15"  method="post" action="admin.php?page=autoblog-options">
                <input type="hidden" name="action" value="form15" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("APP ID","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="app_id"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[17]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Secret Key","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="sec_key" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[18]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <?php if(get_bloginfo('language')=='zh-CN'): ?>
                          <p><a href="http://ai.youdao.com/" target="_blank">申请有道翻译API Key</a></p>
                          <p>
                            有道翻译使用神经网络翻译技术，翻译结果接近人工笔译，更懂中文，推荐使用有道翻译进行中英文转换
                          </p>
                        <?php else: ?>
                          <p><a href="http://ai.youdao.com/" target="_blank">Apply YouDao Translator API Key</a></p>
                          <p>
                            By default, when you make a translation request to the YouDao Translator API, your text is translated using the NMT ( Neural Machine Translation ) model. If the NMT model is not supported for the requested language translation pair, the PBMT ( Phrase-Based Machine Translation ) model is used.
                          </p>
                        <?php endif; ?>



                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If set up correctly, the following language can be translated into other languages', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label><?php echo __("Original Language","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <select class="input-default" name="fromLanguage" ><?php $D544052OH3N9KGA4GJRQ31Y60537A0GKIEQ78N572T2EKCB8336963P720648OD8B5DACAF910EA628737C997694C36951632 = ($_POST['fromLanguage']!='')?$_POST['fromLanguage']:'EN'; echo Q8292HEQ18NSGMT8N2P73UY1022I98JYL4045523IW28775B0AF4BC9F89EC0F60AF0479916C473889::T87LL6FJ7JY2C0TI34EMM33BZ877055OWKUR50T5QQB2606GXVJ07091X42TX9TH9637507F14BD49ADF1E9076223AC9DE25237($D544052OH3N9KGA4GJRQ31Y60537A0GKIEQ78N572T2EKCB8336963P720648OD8B5DACAF910EA628737C997694C36951632); ?></select>
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <textarea style="width: 100%" rows="5"  name="src_text" ><?php echo (isset($_POST['src_text'])&&$_POST['src_text']!='')?stripslashes($_POST['src_text']):'Hello world!'; ?></textarea>
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Translated into","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <select class="input-default" name="toLanguage" ><?php $N2A2G9MF2O178KM645254782HF43646EF97219G61907WZCYA328961U8K9NI12EZJS7W8J6259578609237X5YDR29A7200I6BD3TBIE108P56PF3FCC6E730A750D2EBF37320744BFBDA1696 = ($_POST['toLanguage']!='')?$_POST['toLanguage']:'zh-CHS';echo Q8292HEQ18NSGMT8N2P73UY1022I98JYL4045523IW28775B0AF4BC9F89EC0F60AF0479916C473889::T87LL6FJ7JY2C0TI34EMM33BZ877055OWKUR50T5QQB2606GXVJ07091X42TX9TH9637507F14BD49ADF1E9076223AC9DE25237($N2A2G9MF2O178KM645254782HF43646EF97219G61907WZCYA328961U8K9NI12EZJS7W8J6259578609237X5YDR29A7200I6BD3TBIE108P56PF3FCC6E730A750D2EBF37320744BFBDA1696); ?></select>
                      </td>
                    </tr>

                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <a class="btn btn-primary" data-loading-text="Loading..." onclick="F605ER743XPVEMP7VE036T2WL5D535714197C93165VR1F433NLYML3SO23SM9562XMQ126YF2A5C287D1130F6EC24572BDA34A13B00487()" ><?php echo __('Save'); ?> </a>
                  <input type="submit" name="test_translate" class="btn btn-primary" value="<?php echo __('Test Translate', 'wp-autoblog'); ?>" >
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->

          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Baidu Translator Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==2))echo 'style="display:none;"' ?>>
              <form id="form2"  method="post" action="admin.php?page=autoblog-options">
                <input type="hidden" name="action" value="form2" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("APP ID","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="app_id"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[3]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Secret Key","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="sec_key" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[4]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <?php if(get_bloginfo('language')=='zh-CN'): ?>
                          <p><a href="http://api.fanyi.baidu.com/api/trans/product/index" target="_blank">申请百度翻译API Key</a></p>
                        <?php else: ?>
                          <p><a href="http://api.fanyi.baidu.com/api/trans/product/index" target="_blank">Apply Baidu Translator API Key</a></p>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If set up correctly, the following language can be translated into other languages', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label><?php echo __("Original Language","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <select class="input-default" name="fromLanguage" ><?php $D544052OH3N9KGA4GJRQ31Y60537A0GKIEQ78N572T2EKCB8336963P720648OD8B5DACAF910EA628737C997694C36951632 = ($_POST['fromLanguage']!='')?$_POST['fromLanguage']:'en'; echo FJP6X769ZS3H4F26025B8E1KAV4Y10I223W3AL1A1Y25O0X13JE0M45966YX2XZ344I02Z2BYTR98BJ0AR7VB3S3J4S27314GZ6082HW166X2LNVJ18FXNO7DN65C88VZ3OD61139318A9F387E8FAD2DCA5268E5BD3615::T87LL6FJ7JY2C0TI34EMM33BZ877055OWKUR50T5QQB2606GXVJ07091X42TX9TH9637507F14BD49ADF1E9076223AC9DE25237($D544052OH3N9KGA4GJRQ31Y60537A0GKIEQ78N572T2EKCB8336963P720648OD8B5DACAF910EA628737C997694C36951632); ?></select>
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <textarea style="width: 100%" rows="5"  name="src_text" ><?php echo (isset($_POST['src_text'])&&$_POST['src_text']!='')?stripslashes($_POST['src_text']):'Hello world!'; ?></textarea>
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Translated into","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <select class="input-default" name="toLanguage" ><?php $N2A2G9MF2O178KM645254782HF43646EF97219G61907WZCYA328961U8K9NI12EZJS7W8J6259578609237X5YDR29A7200I6BD3TBIE108P56PF3FCC6E730A750D2EBF37320744BFBDA1696 = ($_POST['toLanguage']!='')?$_POST['toLanguage']:'zh';echo FJP6X769ZS3H4F26025B8E1KAV4Y10I223W3AL1A1Y25O0X13JE0M45966YX2XZ344I02Z2BYTR98BJ0AR7VB3S3J4S27314GZ6082HW166X2LNVJ18FXNO7DN65C88VZ3OD61139318A9F387E8FAD2DCA5268E5BD3615::T87LL6FJ7JY2C0TI34EMM33BZ877055OWKUR50T5QQB2606GXVJ07091X42TX9TH9637507F14BD49ADF1E9076223AC9DE25237($N2A2G9MF2O178KM645254782HF43646EF97219G61907WZCYA328961U8K9NI12EZJS7W8J6259578609237X5YDR29A7200I6BD3TBIE108P56PF3FCC6E730A750D2EBF37320744BFBDA1696); ?></select>
                      </td>
                    </tr>

                  </table>
                </div> <!-- /panel-body -->



              <div class="panel-footer">
                <a class="btn btn-primary" data-loading-text="Loading..." onclick="J2I39436632Q67A68C9E95J54GOO64T66CWKEML850159LEK12VDHN9E8QE97CQ8VXEIZ67D09R6XK98895334NDB0R1A1D1179A20J3C40H6KE5X2M3JQ7OL4479TCD94SI152E3EECC5371B8C430E17B47532496C8057()" ><?php echo __('Save'); ?> </a>
                <input type="submit" name="test_translate" class="btn btn-primary" value="<?php echo __('Test Translate', 'wp-autoblog'); ?>" >
              </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


        </div> <!-- /post-body-content -->
      </div><!-- /post-body -->
    </div><!-- /poststuff -->

  </div>


  <div id="tab-tab3" class="div-tabs ">
    <div style="margin:16px;"></div>
    <div id="poststuff">
      <div id="post-body" class="metabox-holder columns-2">
        <div id="post-body-content">

          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("WordAi Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==3))echo 'style="display:none;"' ?>>
              <form id="form3"  method="post" action="admin.php?page=autoblog-options">
                <input type="hidden" name="action" value="form3" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("User Email","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="wordai_user_email"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][0]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("User Password","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="wordai_user_password" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][1]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Spinner","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <?php
 if(!isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2])) $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2] = 1; ?>
                        <select class="input-default" name="wordai_spinner" id="wordai_spinner">
                          <option value="1" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2]==1) echo 'selected="true"'; ?>><?php echo __('Standard Spinner'); ?></option>
                          <option value="2" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2]==2) echo 'selected="true"'; ?>><?php echo __('Turing Spinner'); ?></option>
                        </select>
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Spinning Quality","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <select class="input-default" name="standard_quality" id="standard_quality" <?php if(@($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2]!=1&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2]!=null))echo 'style="display:none;"'; ?> >
                          <option value="0" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==0) echo 'selected="true"'; ?> >Extremely Unique</option>
                          <option value="25" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==25) echo 'selected="true"'; ?>>Very Unique</option>
                          <option value="50" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==50) echo 'selected="true"'; ?>>Unique</option>
                          <option value="75" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==75) echo 'selected="true"'; ?>>Regular</option>
                          <option value="100" <?php if(!isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]) || ($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==100||$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==null)) echo 'selected="true"'; ?>>Readable</option>
                          <option value="150" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==150) echo 'selected="true"'; ?>>Very Readable</option>
                          <option value="200" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==200) echo 'selected="true"'; ?>>Extremely Readable</option>
                        </select>

                        <select class="input-default" name="turing_quality" id="turing_quality" <?php if(@($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2]!=2))echo 'style="display:none;"'; ?> >
                          <option value="Very Unique" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&& $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]=='Very Unique') echo 'selected="true"'; ?> >Very Unique</option>
                          <option value="Unique" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&& $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]=='Unique') echo 'selected="true"'; ?>>Unique</option>
                          <option value="Normal" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&& $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]=='Normal') echo 'selected="true"'; ?>>Regular</option>
                          <option value="Readable" <?php if(!isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]) || ($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]=='Readable'||$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]==null)) echo 'selected="true"'; ?>>Readable</option>
                          <option value="Very Readable" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3])&& $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][3]=='Very Readable') echo 'selected="true"'; ?>>Very Readable</option>
                        </select>
                      </td>
                    </tr>


                    <tr>
                      <td class="setName"></td>
                      <td>
                        <select class="input-default" name="standard_nonested" id="standard_nonested" <?php if(@($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2]!=1&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2]!=null))echo 'style="display:none;"'; ?>>
                          <option value="off" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][4])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][4]=='off') echo 'selected="true"'; ?>>Automatically Rewrite Sentences (Nested Spintax)</option>
                          <option value="on" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][4])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][4]=='on') echo 'selected="true"'; ?>>Don't Automatically Rewrite Sentences</option>
                        </select>

                        <select class="input-default" name="turing_nonested" id="turing_nonested" <?php if(@($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][2]!=2))echo 'style="display:none;"'; ?>>
                          <option value="on" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][4])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][4]=='on') echo 'selected="true"'; ?>>Automatically Rewrite Sentences (Nested Spintax)</option>
                          <option value="off" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][4])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][4]=='off') echo 'selected="true"'; ?>>Don't Automatically Rewrite Sentences</option>
                        </select>
                      </td>
                    </tr>


                    <tr>
                      <td class="setName"></td>
                      <td>
                        <select class="input-default" name="wordai_sentence">
                          <option value="on" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][5])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][5]=='on') echo 'selected="true"'; ?>>Automatically Add/Remove Sentences (Nested Spintax)</option>
                          <option value="off" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][5])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][5]=='off') echo 'selected="true"'; ?>>Don't Automatically Add/Remove Sentences</option>
                        </select>
                      </td>
                    </tr>

                    <tr>
                      <td class="setName"></td>
                      <td>
                        <select class="input-default" name="wordai_paragraph">
                          <option value="on" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][6])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][6]=='on') echo 'selected="true"'; ?>>Automatically Spin Paragraphs and Lists (Nested Spintax)</option>
                          <option value="off" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][6])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[5][6]=='off') echo 'selected="true"'; ?>>Don't Automatically Spin Paragraphs and Lists</option>
                        </select>
                      </td>
                    </tr>

                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <input type="submit"  class="btn btn-primary" value="<?php echo __('Save'); ?>" >
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Spin Rewriter Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==4))echo 'style="display:none;"' ?>>
              <form id="form4"  method="post" action="admin.php?page=autoblog-options">
                <input type="hidden" name="action" value="form4" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("User Email","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="spin_rewriter_user_email"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][0]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Your Unique API Key","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="spin_rewriter_api_key" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][1]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName"></td>
                      <td>
                        <?php
 if(!isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][2])) $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][2] = 1; ?>
                        <div class="checkbox input-bootstrap">
                          <label><input type="checkbox" name="spin_rewriter_auto_sentences" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][2])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][2]==1)echo 'checked="true"'; ?> /> I want Spin Rewriter to automatically rewrite complete sentences.</label>
                        </div>

                        <div class="checkbox input-bootstrap">
                          <label><input type="checkbox" name="spin_rewriter_auto_paragraphs" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][3])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][3]==1)echo 'checked="true"'; ?> /> I want Spin Rewriter to automatically rewrite entire paragraphs.</label>
                        </div>

                        <div class="checkbox input-bootstrap">
                          <label><input type="checkbox" name="spin_rewriter_auto_new_paragraphs" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][4])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][4]==1)echo 'checked="true"'; ?> /> I want Spin Rewriter to automatically write additional paragraphs on its own.</label>
                        </div>

                        <div class="checkbox input-bootstrap">
                          <label><input type="checkbox" name="spin_rewriter_auto_sentence_trees" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][5])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][5]==1)echo 'checked="true"'; ?> /> I want Spin Rewriter to automatically change the entire structure of phrases and sentences.</label>
                        </div>

                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label>How Adventurous Are You Feeling?</label>
                      </td>
                      <td>
                        <select class="input-default" name="spin_rewriter_confidence_level" >
                          <option value="high" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][6])&& $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][6]=='high') echo 'selected="true"'; ?> >generate as many suggestions as possible (high risk)</option>
                          <option value="medium" <?php if(!isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][6])||($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][6]=='medium'||$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][6]==null)) echo 'selected="true"'; ?>>use suggestions that you believe are correct (recommended)</option>
                          <option value="low" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][6])&& $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][6]=='low') echo 'selected="true"'; ?> >only use suggestions that you're really confident about (low risk)</option>
                        </select>
                      </td>
                    </tr>


                    <tr>
                      <td class="setName"></td>
                      <td>
                        <div class="checkbox input-bootstrap">
                          <label><input type="checkbox" name="spin_rewriter_nested_spintax" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][7])&& $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][7]==1)echo 'checked="true"'; ?> /> find synonyms for single words inside spun phrases as well (multi-level nested spinning)</label>
                        </div>

                        <div class="checkbox input-bootstrap">
                          <label><input type="checkbox" name="spin_rewriter_auto_protected_terms" <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][8])&& $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[6][8]==1)echo 'checked="true"'; ?> /> automatically protect Capitalized Words (except in the title of the article)</label>
                        </div>


                      </td>
                    </tr>



                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <input type="submit"  class="btn btn-primary" value="<?php echo __('Save'); ?>" >
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


        </div> <!-- /post-body-content -->
      </div><!-- /post-body -->
    </div><!-- /poststuff -->
  </div>


  <div id="tab-tab4" class="div-tabs ">
    <div style="margin:16px;"></div>
    <div id="poststuff">
      <div id="post-body" class="metabox-holder columns-2">
        <div id="post-body-content">


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Amazon AWS S3","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==8))echo 'style="display:none;"' ?>>
              <form id="form10"  method="post" action="admin.php?page=autoblog-options" enctype="multipart/form-data">
                <input type="hidden" name="action" value="form10" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Domain","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="domain"  placeholder="default like: https://s3-{Region}.amazonaws.com/{Bucket}/"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][0]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Region"); ?> </label>
                        <p class="desc">eg: us-west-1<br/>
                        <a href="https://docs.aws.amazon.com/general/latest/gr/rande.html#s3_region" target="_blank">more details</a></p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="region" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][1]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Bucket");?> </label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="bucket" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][2]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access key ID","wp-autoblog"); ?></label>
                        <p class="desc">
                        <a href="https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_access-keys.html#Using_CreateAccessKey" target="_blank">more details</a></p>

                      </td>
                      <td>
                        <input type="text" class="form-control"  name="Access_key_ID" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][3]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Secret Access key","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="Secret_Access_key" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][4]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <?php
 if(!isset( $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][5])) { $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][5] = 1; } ?>
                        <p>
                          <input type="checkbox" name="save_copy" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][5]==1) echo 'checked="true"'; ?> /> <?php _e( 'Save a copy on local server', 'wp-autoblog' );?>
                        </p>

                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <p><a href="https://aws.amazon.com/s3/"  target="_blank">Apply Amazon AWS S3</a></p>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If the settings are correct, can upload a image to your Amazon AWS S3 Bucket and appear here.', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label></label>
                      </td>
                      <td>
                        <input disabled="true" type="file" class="btn" name="images_file"  size="60" />
                        <input disabled="true" type="submit" name="upload" class="btn btn-primary" value="<?php echo __('Upload', 'wp-autoblog'); ?>" >

                        <div style="width: 100%;margin-top:10px;" >
                          <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][6])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][6]!=''){ echo '<div class="view_img"><img src='.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][6].'?t='.time().'  width="600"/></div>'; echo '<p>'.__('The image URL','wp-autopost').' : <a href="'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][6].'?t='.time().'" target="_blank">'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[12][6].'</a></p>'; } ?>
                        </div>

                      </td>
                    </tr>




                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Trial version this settings will not working, use this featured please upgrade to full version','wp-autoblog'); ?></span>
                </div>

                <div class="panel-footer">
                  <button class="btn btn-primary" data-loading-text="Loading..." disabled="true"><?php echo __('Save'); ?> </button>
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Google Cloud Storage","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==9))echo 'style="display:none;"' ?>>
              <form id="form11"  method="post" action="admin.php?page=autoblog-options" enctype="multipart/form-data">
                <input type="hidden" name="action" value="form11" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Domain","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="domain"  placeholder="default like: https://storage.googleapis.com/{Bucket}/"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][0]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Bucket");?> </label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="bucket" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][1]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Project Id"); ?> </label>
                        <p class="desc">The project ID from the <a href="https://console.cloud.google.com/" target="_blank">Google Developer's Console</a>.</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="projectId" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][2]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Credentials file contents","wp-autoblog"); ?></label>
                        <p class="desc">
                          The contents of the service account credentials .json file retrieved from the Google Developer's Console.
                          <a href="https://cloud.google.com/storage/docs/authentication#generating-a-private-key" target="_blank">more details</a></p>
                      </td>
                      <td>
                        <textarea class="form-control"  rows="5" name="keyFile" placeholder='Example:
{
  "type": "service_account",
  "project_id": "xxxxxxx",
  "private_key_id": "xxxxxxxxxx",
  "private_key": "xxxxxxx",
  "client_email": "xxxxx",
  "client_id": "xxxxxxxx",
  "auth_uri": "xxxxxx",
  "token_uri": "xxxxxxx",
  "auth_provider_x509_cert_url": "xxxxxxxxxx",
  "client_x509_cert_url": "xxxxxxxxxxxx"
}'><?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][3]; ?></textarea>
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <?php
 if(!isset( $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][4])) { $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][4] = 1; } ?>
                        <p>
                          <input type="checkbox" name="save_copy" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][4]==1) echo 'checked="true"'; ?> /> <?php _e( 'Save a copy on local server', 'wp-autoblog' );?>
                        </p>

                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <p><a href="https://cloud.google.com/storage/"  target="_blank">Apply Google Cloud Storage</a></p>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If the settings are correct, can upload a image to your Google Cloud Storage Bucket and appear here.', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label></label>
                      </td>
                      <td>
                        <input disabled="true" type="file" class="btn" name="images_file"  size="60" />
                        <input disabled="true" type="submit" name="upload" class="btn btn-primary" value="<?php echo __('Upload', 'wp-autoblog'); ?>" >

                        <div style="width: 100%;margin-top:10px;" >
                          <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][5])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][5]!=''){ echo '<div class="view_img"><img src='.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][5].'?t='.time().'  width="600"/></div>'; echo '<p>'.__('The image URL','wp-autopost').' : <a href="'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][5].'?t='.time().'" target="_blank">'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[13][5].'</a></p>'; } ?>
                        </div>

                      </td>
                    </tr>




                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Trial version this settings will not working, use this featured please upgrade to full version','wp-autoblog'); ?></span>
                </div>

                <div class="panel-footer">
                  <button class="btn btn-primary" data-loading-text="Loading..." disabled="true"><?php echo __('Save'); ?> </button>
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Qiniu Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all"  <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==5))echo 'style="display:none;"' ?>>
              <form id="form5"  method="post" action="admin.php?page=autoblog-options" enctype="multipart/form-data">
                <input type="hidden" name="action" value="form5" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("The Domain of Qiniu Bucket","wp-autoblog"); ?></label>
                        <p class="desc">http://xxxx.xxxx.com/</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="domain"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][0]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Bucket","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="bucket" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][1]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Key","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="access_key" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][2]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Secret Key","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="secret_key" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][3]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <?php
 if(!isset( $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][5])) { $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][5] = 1; } ?>
                        <p>
                          <input type="checkbox" name="save_copy" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][5]==1) echo 'checked="true"'; ?> /> <?php _e( 'Save a copy on local server', 'wp-autoblog' );?>
                        </p>

                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <?php if(get_bloginfo('language')=='zh-CN'): ?>
                          <p><a href="javascript:void(0);"  onclick="H3068VW95C2NQZ52ADW7TX0N2J6X1T9BDLF8D7JMB3U8PVMOS4Q8FB51E792E57F016280C4A477BBEBA7120153('qiniu')" >申请七牛云服务</a></p>
                        <?php else: ?>
                          <p><a href="javascript:void(0);" onclick="H3068VW95C2NQZ52ADW7TX0N2J6X1T9BDLF8D7JMB3U8PVMOS4Q8FB51E792E57F016280C4A477BBEBA7120153('qiniu')">Apply Qiniu Cloud Storage</a></p>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If the settings are correct, can upload a image to your Qiniu Bucket and appear here.', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label></label>
                      </td>
                      <td>
                        <input disabled="true" type="file" class="btn" name="images_file"  size="60" />
                        <input disabled="true" type="submit" name="upload" class="btn btn-primary" value="<?php echo __('Upload', 'wp-autoblog'); ?>" >

                        <div style="width: 100%;margin-top:10px;" >
                          <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][4])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][4]!=''){ echo '<div class="view_img"><img src='.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][4].'?t='.time().'  width="600"/></div>'; echo '<p>'.__('The image URL','wp-autopost').' : <a href="'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][4].'?t='.time().'" target="_blank">'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[7][4].'</a></p>'; } ?>
                        </div>

                      </td>
                    </tr>




                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Trial version this settings will not working, use this featured please upgrade to full version','wp-autoblog'); ?></span>
                </div>

                <div class="panel-footer">
                  <button class="btn btn-primary" data-loading-text="Loading..." disabled="true"><?php echo __('Save'); ?> </button>
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Aliyun OSS Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==6))echo 'style="display:none;"' ?>>
              <form id="form8"  method="post" action="admin.php?page=autoblog-options" enctype="multipart/form-data">
                <input type="hidden" name="action" value="form8" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Domain","wp-autoblog"); ?></label>
                        <p class="desc">http://xxxx.xxxx.com/</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="domain"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][0]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Bucket"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="bucket" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][1]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Key ID","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="access_key_id" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][2]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Key Secret","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="access_key_secret" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][3]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("EndPoint","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="EndPoint" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][4]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <?php
 if(!isset( $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][5])) { $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][5] = 1; } ?>
                        <p>
                          <input type="checkbox" name="save_copy" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][5]==1) echo 'checked="true"'; ?> /> <?php _e( 'Save a copy on local server', 'wp-autoblog' );?>
                        </p>

                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <?php if(get_bloginfo('language')=='zh-CN'): ?>
                          <p><a href="https://www.aliyun.com/product/oss"  target="_blank">申请阿里云OSS服务</a></p>
                        <?php else: ?>
                          <p><a href="https://www.aliyun.com/product/oss"  target="_blank">Apply Aliyun OSS Cloud Storage</a></p>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If the settings are correct, can upload a image to your Aliyun OSS Bucket and appear here.', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label></label>
                      </td>
                      <td>
                        <input disabled="true" type="file" class="btn" name="images_file"  size="60" />
                        <input disabled="true" type="submit" name="upload" class="btn btn-primary" value="<?php echo __('Upload', 'wp-autoblog'); ?>" >

                        <div style="width: 100%;margin-top:10px;" >
                          <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][6])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][6]!=''){ echo '<div class="view_img"><img src='.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][6].'?t='.time().'  width="600"/></div>'; echo '<p>'.__('The image URL','wp-autopost').' : <a href="'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][6].'?t='.time().'" target="_blank">'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[10][6].'</a></p>'; } ?>
                        </div>

                      </td>
                    </tr>




                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Trial version this settings will not working, use this featured please upgrade to full version','wp-autoblog'); ?></span>
                </div>

                <div class="panel-footer">
                  <button class="btn btn-primary" data-loading-text="Loading..." disabled="true"><?php echo __('Save'); ?> </button>
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Tencent COS Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==7))echo 'style="display:none;"' ?>>
              <form id="form9"  method="post" action="admin.php?page=autoblog-options" enctype="multipart/form-data">
                <input type="hidden" name="action" value="form9" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Domain","wp-autoblog"); ?></label>
                        <p class="desc">http://xxxx.xxxx.com/</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="domain"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][0]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Region"); ?> </label>
                        <p class="desc">eg: ap-shanghai</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="region" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][1]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Bucket"); ?> </label>
                          <p class="desc"><?php if(get_bloginfo('language')=='zh-CN'): ?>存储桶 <?php endif; ?><br/>BucketName-{APPID}<br/>eg: newproject1-1250000000</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="bucket" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][2]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("APPID","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="app_id" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][3]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("SecretId","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="SecretId" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][4]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("SecretKey","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="SecretKey" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][5]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <?php
 if(!isset( $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][6])) { $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][6] = 1; } ?>
                        <p>
                          <input type="checkbox" name="save_copy" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][6]==1) echo 'checked="true"'; ?> /> <?php _e( 'Save a copy on local server', 'wp-autoblog' );?>
                        </p>

                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <?php if(get_bloginfo('language')=='zh-CN'): ?>
                          <p><a href="https://cloud.tencent.com/product/cos"  target="_blank">申请腾讯COS服务</a></p>
                        <?php else: ?>
                          <p><a href="https://cloud.tencent.com/product/cos"  target="_blank">Apply Tencent COS Cloud Storage</a></p>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If the settings are correct, can upload a image to your Tencent COS Bucket and appear here.', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label></label>
                      </td>
                      <td>
                        <input disabled="true" type="file" class="btn" name="images_file"  size="60" />
                        <input disabled="true" type="submit" name="upload" class="btn btn-primary" value="<?php echo __('Upload', 'wp-autoblog'); ?>" >

                        <div style="width: 100%;margin-top:10px;" >
                          <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][7])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][7]!=''){ echo '<div class="view_img"><img src='.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][7].'?t='.time().'  width="600"/></div>'; echo '<p>'.__('The image URL','wp-autopost').' : <a href="'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][7].'?t='.time().'" target="_blank">'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[11][7].'</a></p>'; } ?>
                        </div>

                      </td>
                    </tr>




                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Trial version this settings will not working, use this featured please upgrade to full version','wp-autoblog'); ?></span>
                </div>

                <div class="panel-footer">
                  <button class="btn btn-primary" data-loading-text="Loading..." disabled="true"><?php echo __('Save'); ?> </button>
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Baidu BOS Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all" <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==11))echo 'style="display:none;"' ?>>
              <form id="form13"  method="post" action="admin.php?page=autoblog-options" enctype="multipart/form-data">
                <input type="hidden" name="action" value="form13" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Domain","wp-autoblog"); ?></label>
                        <p class="desc">http://xxxx.xxxx.com/</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="domain"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][0]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Bucket"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="bucket" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][1]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Key","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="access_key" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][2]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("Secret Key","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="secret_key" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][3]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("EndPoint","wp-autoblog"); ?></label>
                        <p class="desc">北京区域：http://bj.bcebos.com<br/>广州区域：http://gz.bcebos.com<br/>苏州区域：http://su.bcebos.com</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="EndPoint" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][4]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <?php
 if(!isset( $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][5])) { $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][5] = 1; } ?>
                        <p>
                          <input type="checkbox" name="save_copy" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][5]==1) echo 'checked="true"'; ?> /> <?php _e( 'Save a copy on local server', 'wp-autoblog' );?>
                        </p>

                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <?php if(get_bloginfo('language')=='zh-CN'): ?>
                          <p><a href="https://cloud.baidu.com/product/bos.html"  target="_blank">申请百度云BOS服务</a></p>
                        <?php else: ?>
                          <p><a href="https://cloud.baidu.com/product/bos.html"  target="_blank">Apply Baidu BOS Cloud Storage</a></p>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If the settings are correct, can upload a image to your Baidu BOS Bucket and appear here.', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label></label>
                      </td>
                      <td>
                        <input disabled="true" type="file" class="btn" name="images_file"  size="60" />
                        <input disabled="true" type="submit" name="upload" class="btn btn-primary" value="<?php echo __('Upload', 'wp-autoblog'); ?>" >

                        <div style="width: 100%;margin-top:10px;" >
                          <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][6])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][6]!=''){ echo '<div class="view_img"><img src='.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][6].'?t='.time().'  width="600"/></div>'; echo '<p>'.__('The image URL','wp-autopost').' : <a href="'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][6].'?t='.time().'" target="_blank">'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[15][6].'</a></p>'; } ?>
                        </div>

                      </td>
                    </tr>




                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Trial version this settings will not working, use this featured please upgrade to full version','wp-autoblog'); ?></span>
                </div>

                <div class="panel-footer">
                  <button class="btn btn-primary" data-loading-text="Loading..." disabled="true"><?php echo __('Save'); ?> </button>
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Upyun Options","wp-autoblog"); ?></h5>
            </div>

            <div class="panel-all"  <?php if(@!($A8A5611471495O43R1RB0TYXR38C2U9075E208S16PC9070VMG8FXJ9D20E6NNVS1N015Z576E2BAAF3B97DBEEF01C0043275F9A0E78239['showBox']==12))echo 'style="display:none;"' ?>>
              <form id="form14"  method="post" action="admin.php?page=autoblog-options" enctype="multipart/form-data">
                <input type="hidden" name="action" value="form14" />

                <div class="panel-body" style="padding:0;margin:0;">
                  <table class="table settingTable">

                    <tr>
                      <td class="setName">
                        <label><?php echo __("Access Domain","wp-autoblog"); ?></label>
                        <p class="desc">http://xxxx.xxxx.com/</p>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="domain"  value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][0]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("服务名称(Bucket)","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="bucket" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][1]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                        <label><?php echo __("操作员","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="OperatorName" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][2]; ?>" >
                      </td>
                    </tr>


                    <tr>
                      <td class="setName">
                        <label><?php echo __("操作员密码","wp-autoblog"); ?></label>
                      </td>
                      <td>
                        <input type="text" class="form-control"  name="OperatorPwd" value="<?php echo $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][3]; ?>" >
                      </td>
                    </tr>

                    <tr>
                      <td class="setName">
                      </td>
                      <td>
                        <?php
 if(!isset( $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][5])) { $U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][5] = 1; } ?>
                        <p>
                          <input type="checkbox" name="save_copy" <?php if($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][5]==1) echo 'checked="true"'; ?> /> <?php _e( 'Save a copy on local server', 'wp-autoblog' );?>
                        </p>

                      </td>
                    </tr>

                    <tr>
                      <td colspan="2">
                        <?php if(get_bloginfo('language')=='zh-CN'): ?>
                          <p><a href="javascript:void(0);"  onclick="H3068VW95C2NQZ52ADW7TX0N2J6X1T9BDLF8D7JMB3U8PVMOS4Q8FB51E792E57F016280C4A477BBEBA7120153('upyun')" >申请又拍云服务</a></p>
                        <?php else: ?>
                          <p><a href="javascript:void(0);" onclick="H3068VW95C2NQZ52ADW7TX0N2J6X1T9BDLF8D7JMB3U8PVMOS4Q8FB51E792E57F016280C4A477BBEBA7120153('upyun')">Apply Upyun Cloud Storage</a></p>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2">
                        <?php _e( 'If the settings are correct, can upload a image to your Upyun Bucket and appear here.', 'wp-autoblog' );?>
                      </td>
                    </tr>
                    <tr>
                      <td class="setName">
                        <label></label>
                      </td>
                      <td>
                        <input disabled="true" type="file" class="btn" name="images_file"  size="60" />
                        <input disabled="true" type="submit" name="upload" class="btn btn-primary" value="<?php echo __('Upload', 'wp-autoblog'); ?>" >

                        <div style="width: 100%;margin-top:10px;" >
                          <?php if(isset($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][4])&&$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][4]!=''){ echo '<div class="view_img"><img src='.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][4].'?t='.time().'  width="600"/></div>'; echo '<p>'.__('The image URL','wp-autopost').' : <a href="'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][4].'?t='.time().'" target="_blank">'.$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][0].$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[16][4].'</a></p>'; } ?>
                        </div>

                      </td>
                    </tr>




                  </table>
                </div> <!-- /panel-body -->


                <div class="panel-footer">
                  <span style="display:inline-block;font-weight:bold;padding:5px;background-color:red;color:#FFFFFF;"><?php echo __('Trial version this settings will not working, use this featured please upgrade to full version','wp-autoblog'); ?></span>
                </div>

                <div class="panel-footer">
                  <button class="btn btn-primary" data-loading-text="Loading..." disabled="true"><?php echo __('Save'); ?> </button>
                </div>
              </form>


            </div> <!-- /panel-all -->

          </div> <!-- /panel -->


        </div> <!-- /post-body-content -->
      </div><!-- /post-body -->
    </div><!-- /poststuff -->
  </div>

  <div id="tab-tab5" class="div-tabs ">
    <div style="margin:16px;"></div>
    <div id="poststuff">
      <div id="post-body" class="metabox-holder columns-2">
        <div id="post-body-content">

          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Watermark","wp-autoblog"); ?></h5>
            </div>

                <table class="table" style="margin-bottom: 0;">
                  <thead>
                  <tr>
                    <th style="text-align:center;"><?php echo __('Watermark Name','wp-autoblog'); ?></th>
                    <th style="text-align:center;"><?php echo __('Watermark Type','wp-autoblog'); ?></th>
                    <th style="text-align:center;"><?php echo __('Preview'); ?></th>
                  </tr>
                  </thead>
                  <tbody>

                  <?php
 if(count($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[8])>0){ foreach($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[8] as $Z467702E35LX79G5V4R1K0EP1Q3253MRD9LA7732B068931CC450442B63F5B3D276EA42974653=>$QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133){ ?>

                       <tr >
                         <td style="text-align:center;">
                           <strong><?php echo $Z467702E35LX79G5V4R1K0EP1Q3253MRD9LA7732B068931CC450442B63F5B3D276EA42974653; ?></strong>
                           <div class="row-actions">
                             <a  class="opt-link"  href="admin.php?page=autoblog-options-watermark&wm_name=<?php echo $Z467702E35LX79G5V4R1K0EP1Q3253MRD9LA7732B068931CC450442B63F5B3D276EA42974653; ?>" ><?php echo __('Edit'); ?></a> |
                             <a  class='opt-link-red opt-link' href="?page=autoblog-options&del_wm_name=<?php echo $Z467702E35LX79G5V4R1K0EP1Q3253MRD9LA7732B068931CC450442B63F5B3D276EA42974653; ?>""><?php echo __('Delete','wp-autoblog'); ?></a></span>
                           </div>
                         </td>
                         <td style="text-align:center;">
                           <?php if($QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['wm_type']==0) _e( 'Text', 'wp-autoblog' ); else _e( 'Image', 'wp-autoblog' ); ?>
                         </td>
                         <td style="text-align:center;">
                           <div class="watermark_preview_pic" >
                             <?php
 if($QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['wm_type']==0){ ?>

                               <?php
 $PKC57KKNUMK12WU2MY93MIUV1W412K982719YX8BBVR4FK6H380EX8BFUHWJA189ZN39C3E24B43B0AEE35624CD95B910189B3DC2311608 = hexdec( substr( $QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['wm_color'], 1, 2 ) ); $AF9EB0JI258S8RBS13I5X9Q4VRBOIBA067DOH20A8E91NT2238M096X66X3MWN5986D794NN376IV57N62ZDT56H37MZP7R280324UEMWUQ9D4Y535X84E4362Z590Q4X4E565UJSB2F5FF47436671B6E533D8DC3614845D2711 = hexdec( substr( $QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['wm_color'], 3, 2 ) ); $E4G1JNG9OJ4578N58OQ3D780F33T9P53292EB5FFEE6AE2FEC3AD71C777531578F6346 = hexdec( substr( $QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['wm_color'], 5, 2 ) ); $L595ID9G491IEA75MTE81149594W7MLYO531DL0WJ71OX3ZF47S5497703MH7T0H2PPQI17W6Q9F9680OJ67T5M395E496Z9I9VB0CCJ22R6FR69D077319XIKWY6D2Z9OVAY540M2EK01QYD38A716B9213967E8FA5ED80445E3E70A0733 = plugins_url('/wp-autoblog/libs/src/image/image.php').'?text='.urlencode($QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['wm_text']).'&size='.urlencode($QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['wm_size']).'&font='.urlencode($QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['wm_font']).'&r='.$PKC57KKNUMK12WU2MY93MIUV1W412K982719YX8BBVR4FK6H380EX8BFUHWJA189ZN39C3E24B43B0AEE35624CD95B910189B3DC2311608.'&g='.$AF9EB0JI258S8RBS13I5X9Q4VRBOIBA067DOH20A8E91NT2238M096X66X3MWN5986D794NN376IV57N62ZDT56H37MZP7R280324UEMWUQ9D4Y535X84E4362Z590Q4X4E565UJSB2F5FF47436671B6E533D8DC3614845D2711.'&b='.$E4G1JNG9OJ4578N58OQ3D780F33T9P53292EB5FFEE6AE2FEC3AD71C777531578F6346; ?>

                               <img src="<?php echo $L595ID9G491IEA75MTE81149594W7MLYO531DL0WJ71OX3ZF47S5497703MH7T0H2PPQI17W6Q9F9680OJ67T5M395E496Z9I9VB0CCJ22R6FR69D077319XIKWY6D2Z9OVAY540M2EK01QYD38A716B9213967E8FA5ED80445E3E70A0733; ?>" alt="" />


                             <?php  }else{ ?>
                               <img src="<?php echo $QJ1SN49135714C1042VF3YL45TN5S7KR99Z0796X177T12MMR38K982XF2457O1A4TWMT662X94CQ83I90QWQY93HQR84U3O55O08F58274N29CA763A3EF2B2EDB877CD46423AFF356133['upload_image_url']; ?>" alt="" />
                             <?php  }?>
                           </div>
                         </td>
                       </tr>

                  <?php
 } } ?>
                  </tbody>
                </table>
                <div class="panel-footer">
                  <a class="btn btn-primary"  href="admin.php?page=autoblog-options-watermark" ><?php echo __('Add'); ?> </a>
                </div>


          </div> <!-- /panel -->


        </div> <!-- /post-body-content -->
      </div><!-- /post-body -->
    </div><!-- /poststuff -->
  </div>

  <div id="tab-tab6" class="div-tabs ">
    <div style="margin:16px;"></div>
    <div id="poststuff">
      <div id="post-body" class="metabox-holder columns-2">
        <div id="post-body-content">

          <div class="panel panel-default">

            <div class="panel-heading panel-toggle">
              <h5 class="panel-title"><?php echo __("Proxy","wp-autoblog"); ?></h5>
            </div>

            <table class="table" style="margin-bottom: 0;">
              <thead>
              <tr>
                <th scope="col" width="250" style="text-align:center;"><?php _e( 'Proxy Name', 'wp-autoblog' );?></th>
                <th scope="col" width="150" style="text-align:center;"><?php _e( 'Proxy Type', 'wp-autoblog' );?></th>
                <th scope="col" width="250" style="text-align:center;"><?php _e( 'Hostname / IP', 'wp-autoblog' );?></th>
                <th scope="col" width="150" style="text-align:center;"><?php _e( 'Port', 'wp-autoblog' );?></th>
                <th scope="col" width="150" style="text-align:center;"><?php _e( 'User', 'wp-autoblog' );?></th>
                <th scope="col" width="150" style="text-align:center;"><?php _e( 'Password', 'wp-autoblog' );?></th>
              </tr>
              </thead>
              <tbody>

              <?php
 if(count(@$U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[9])>0){ foreach($U5H8G4034QP0EL5GFH0I65ZS3P7AR856Y0S94118231O40R5F2UNEM4X8T9652L6425OUF9A32L0U209223VSL82727ITW4RU9CY49XN7U60840DAC048YJ4K793DA65A9FD0004D9477AEAC024E08E152696[9] as $Z467702E35LX79G5V4R1K0EP1Q3253MRD9LA7732B068931CC450442B63F5B3D276EA42974653=>$QER890PFL12ZF6TOL19Z6GO3JY5081C87T74871GB05BEL3ENL73O0ZM619V5T1K77O078PU207T71YW0O04319V36S7YMXZ62P5U87DC998508D1WG85719EE8N602Q37I85KA69U262529666211921AFB94AC68513B7D9273FC4508){ ?>

                  <tr >
                    <td style="text-align:center;">
                      <strong><?php echo $Z467702E35LX79G5V4R1K0EP1Q3253MRD9LA7732B068931CC450442B63F5B3D276EA42974653; ?></strong>
                      <div class="row-actions">
                        <a  class="opt-link"  href="admin.php?page=autoblog-options-proxy&proxy_name=<?php echo $Z467702E35LX79G5V4R1K0EP1Q3253MRD9LA7732B068931CC450442B63F5B3D276EA42974653; ?>" ><?php echo __('Edit'); ?></a> |
                        <a  class='opt-link-red opt-link' href="?page=autoblog-options&del_proxy_name=<?php echo $Z467702E35LX79G5V4R1K0EP1Q3253MRD9LA7732B068931CC450442B63F5B3D276EA42974653; ?>""><?php echo __('Delete','wp-autoblog'); ?></a></span>
                      </div>
                    </td>
                    <td style="text-align:center;">
                      <?php if($QER890PFL12ZF6TOL19Z6GO3JY5081C87T74871GB05BEL3ENL73O0ZM619V5T1K77O078PU207T71YW0O04319V36S7YMXZ62P5U87DC998508D1WG85719EE8N602Q37I85KA69U262529666211921AFB94AC68513B7D9273FC4508['px_type']==0) _e( 'HTTP', 'wp-autoblog' ); else _e( 'Socks5', 'wp-autoblog' ); ?>
                    </td>
                    <td style="text-align:center;">
                      <?php echo $QER890PFL12ZF6TOL19Z6GO3JY5081C87T74871GB05BEL3ENL73O0ZM619V5T1K77O078PU207T71YW0O04319V36S7YMXZ62P5U87DC998508D1WG85719EE8N602Q37I85KA69U262529666211921AFB94AC68513B7D9273FC4508['px_ip']; ?>
                    </td>
                    <td style="text-align:center;">
                      <?php echo $QER890PFL12ZF6TOL19Z6GO3JY5081C87T74871GB05BEL3ENL73O0ZM619V5T1K77O078PU207T71YW0O04319V36S7YMXZ62P5U87DC998508D1WG85719EE8N602Q37I85KA69U262529666211921AFB94AC68513B7D9273FC4508['px_port']; ?>
                    </td>
                    <td style="text-align:center;">
                      <?php echo $QER890PFL12ZF6TOL19Z6GO3JY5081C87T74871GB05BEL3ENL73O0ZM619V5T1K77O078PU207T71YW0O04319V36S7YMXZ62P5U87DC998508D1WG85719EE8N602Q37I85KA69U262529666211921AFB94AC68513B7D9273FC4508['px_user']; ?>
                    </td>
                    <td style="text-align:center;">
                      <?php echo $QER890PFL12ZF6TOL19Z6GO3JY5081C87T74871GB05BEL3ENL73O0ZM619V5T1K77O078PU207T71YW0O04319V36S7YMXZ62P5U87DC998508D1WG85719EE8N602Q37I85KA69U262529666211921AFB94AC68513B7D9273FC4508['px_pass']; ?>
                    </td>

                  </tr>

                  <?php
 } } ?>
              </tbody>
            </table>
            <div class="panel-footer">
              <a class="btn btn-primary"  href="admin.php?page=autoblog-options-proxy" ><?php echo __('Add'); ?> </a>
            </div>


          </div> <!-- /panel -->


        </div> <!-- /post-body-content -->
      </div><!-- /post-body -->
    </div><!-- /poststuff -->
  </div>

  <!--
  <div id="tab-tab7" class="div-tabs ">
    Other Options
  </div>
  -->





  <a href="#" id="hiddenfocus"></a>
</div> <!-- end <div class="wrap"> -->

<script type="text/javascript">

  function UX2ZK6PY9588ZOL4S231P712061W4KR4TCX2D2M21TK0P193R3LM03L5J77M44346XF22UY52YPZ3DAAE6EB8455514DC6B78155D198CAAF968603(var1){
    //var
    if(var1==0){
      jQuery('#cron').hide();
    }
    if(var1==1){
      jQuery('#cron').show();
    }
  }


  jQuery('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    jQuery('#hiddenfocus').focus();
  })


  jQuery('div.div-tabs').hide();

  <?php
 if(!isset($OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702)): ?>
  jQuery('h2 a.nav-tab').first().addClass('nav-tab-active');
  jQuery('div.div-tabs').first().show();
  <?php else:?>
  jQuery('#tab-title-tab<?php echo $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702; ?>').addClass('nav-tab-active');
  jQuery('#tab-tab<?php echo $OL26VR0B3TE7407URNQX830V273S436T589T4MU663G9283R8L7OG676L16J1S8908RA328YF2K8F4X91965K9OB9X3162B912IS7JX6G7315I107PDFFZU3J7B4PC2152LH44G56M8E41763DE3DA7835F6E22B39086F6D8C529729702; ?>').show();
  <?php endif;?>

  jQuery(function($){
    jQuery('h2 a.nav-tab').on('click',function(){
      jQuery('h2 a.nav-tab').removeClass('nav-tab-active');
      jQuery(this).addClass('nav-tab-active');
      jQuery('div.div-tabs').hide();
      jQuery('#'+jQuery(this)[0].id.replace('title-','')).fadeIn("fast");
      jQuery('#current_tab').val(jQuery(this)[0].id.replace('tab-title-',''));
      jQuery('#hiddenfocus').focus();
    });


    jQuery('#wordai_spinner').change(function(){
      var sSwitch = jQuery(this).val();
      if(sSwitch == 1){

        jQuery("#standard_quality").show();
        jQuery("#turing_quality").hide();

        jQuery("#standard_nonested").show();
        jQuery("#turing_nonested").hide();

      }else if(sSwitch == 2){
        jQuery("#standard_quality").hide();
        jQuery("#turing_quality").show();

        jQuery("#standard_nonested").hide();
        jQuery("#turing_nonested").show();
      }
    });

  });


  function H3068VW95C2NQZ52ADW7TX0N2J6X1T9BDLF8D7JMB3U8PVMOS4Q8FB51E792E57F016280C4A477BBEBA7120153(s){
    if(s=='qiniu'){
      window.open("https://portal.qiniu.com/signup?code=3lkd3ogublbv6");
    }

    if(s=='upyun'){
      window.open("https://console.upyun.com/register/?invite=SJD-F-8rM");
    }

  }



  jQuery(function($){
    jQuery(".panel-toggle").click(function(){jQuery(this).next(".panel-all").slideToggle('fast');});
    jQuery('[data-toggle="popover"]').popover();
  });

  function S2HYXBGEQ76LA376V6P4PE03Y5KM9OB550276I9F2242H6F604XGH7A66SWS2MY24R5V3F60J3H39C2BC284BAAECB183049388F3BCA77748244(){
    document.getElementById("form1").submit();
  }

  function J2I39436632Q67A68C9E95J54GOO64T66CWKEML850159LEK12VDHN9E8QE97CQ8VXEIZ67D09R6XK98895334NDB0R1A1D1179A20J3C40H6KE5X2M3JQ7OL4479TCD94SI152E3EECC5371B8C430E17B47532496C8057(){
    document.getElementById("form2").submit();
  }

  function L75Q6MY23VW5641947Q7BC2AQ9L40IG2P9040303R08JEV750741156I0W0J5T5Y7HR57074Q5O20YQBXD7F4658A00B0CA5DC1078963D686F4A0FB81D54531(){
    document.getElementById("form5").submit();
  }

  function V25G3IY2639385N63DOSZ5TPS416MTXOT0QDODP89G88WJQE1971W4D2X04U6H3J2Y08I86E14YWX5E2VIXE1N71806LL078N6646H43WHW7G62WFMZKCV1EC463W7T57V65146Q1946SJ8NU6T3CC4E2AF9C5573D7F683DE0BEB63838E0368(){
    document.getElementById("form8").submit();
  }

  function PLRCS0310G5TW2VW0J1BIL94CL6M84A71942YDV9DTU700JM6GSP7SXF7816SP24L761AIYMS9V4Q3T7N622A6M959F1B5B0DE926C1695719D529889EA44497(){
    document.getElementById("form9").submit();
  }

  function H7OT1SC796608946D0Q0A7G8BY4HSR60C7045F7BE041322C5DCB78FD5AF721B883403(){
    document.getElementById("form10").submit();
  }

  function W4TOXGW239YOGASO43P29OOS8TCR5992R1ME4U4Q4FZCJO54L548790FK6MP063644604Q86Z3MZ25R4Y0C540694W6J36HG7N0O495033AW8G0508N5670UTB86BR733F72FCE81F209D9C4DB22967087B8C08559(){
    document.getElementById("form11").submit();
  }

  function U3U4PB474V29ADP8472J56E191ONC2B0SM2A651VN4380N7NZ45CK6858IEZPCQ3JX306R93011815455F49C30ABF3A098CF8D7594225(){
    document.getElementById("form12").submit();
  }

  function GCIVZ342F9LBI006AL31731J978471L3U3W4JQG89J348SSFRT847743F7U6472X80T6L5533FEA1DB05A92C5707463436BC2C7E25037(){
    document.getElementById("form13").submit();
  }

  function R1J75P58680N0BI76YB481R2E9Y5K9P42R5630V88I0B3Q1DHXCHI211W0IC1955JH419V7064EW538A1A6586E90928C60AC63D0E05A8AC0634(){
    document.getElementById("form14").submit();
  }

  function F605ER743XPVEMP7VE036T2WL5D535714197C93165VR1F433NLYML3SO23SM9562XMQ126YF2A5C287D1130F6EC24572BDA34A13B00487(){
    document.getElementById("form15").submit();
  }





</script>